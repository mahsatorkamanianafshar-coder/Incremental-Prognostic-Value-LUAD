# Supplementary File S25 — Reissued October 18, 2026

## Provenance and identity
This S25 archive was **repackaged, not rerun**, from the author-supplied `M20_inner_crossfit_COMPLETE_2026-10-16_v2.zip` generated October 16, 2026. No model coefficients, patient predictions, or performance numbers have been recomputed or altered for this reissue. The original ZIP SHA-256 is listed in `ORIGINAL_SOURCE_SHA256.txt`.

The original source ZIP has 107 file payloads: 106 data/log/code items listed in its `MANIFEST.tsv` and that manifest itself. All 106 manifest entries passed exact length and SHA-256 verification; ZIP CRC validation passed. The reissued archive normalizes historical Windows backslash path separators to forward slashes and adds wrapper documentation, provenance and a new complete checksum manifest.

## Authoritative results
- Primary corrected internal run: 10 repeats x 5 outer folds, 250 inner training partitions, 3,520 OOF predictions for 352 patients.
- Clinical C-index: 0.6551651095; combined C-index: 0.6754450030; observed delta C: +0.0202798935.
- Conditional patient-cluster bootstrap 95% interval: -0.0058358656 to +0.0448536230; 1,000 replicates.
- Final frozen joint model: 10 genes, linear age/stage/recorded gender with no smoking covariate; alpha=0.25, lambda.min=0.0904292498840317. Final genes/coefficient outputs and frozen RDS are included.
- The external frozen GSE72094, GSE31210 full and GSE31210 protocol-aligned runs and associated 1,000-replicate patient bootstraps are included.

## Essential scope and limitations
- This is **not a stand-alone rerun from raw RNA-seq counts**. Large source count matrices, all large expression/discovery cache payloads, and the original R package library are not duplicated. Original input checksums, discovery-cache index, scripts and logs are supplied; an independent exact end-to-end rerun requires the matching original inputs and R environment.
- The original run's available warning logs do not establish that every individual Cox or DESeq2 warning was benign.
- The 1,000 bootstrap replicates are conditional on existing OOF predictions; bootstrap replicates did not retrain the entire nested algorithm.
- The 30–730-day GSE72094 IBS (Supplementary Table S37) was a separate archived post-hoc diagnostic and is **not** reproduced by this source run, which uses the standard 30–1,825-day window for the main 102-point external IBS evaluation.
- The separate post-hoc audit of 300 Cox screens belongs to a different sensitivity workflow and is not included as a canonical recalculation in this S25.
- Original `output_audit/AUDIT_REPORT.md` and `RUN_DESIGN.md` describe an earlier stage. The later `README_FINAL.md` and `final_audit/FINAL_AUDIT_REPORT.md` supersede stage-specific statements about work then pending.
- The original files refer to `corrected_S25` or an older `S25` as the **historical** pre-inner-crossfit comparator. These internal source labels have deliberately not been modified.
- This packaging is an integrity review by the assistant, **not** a second analyst's rerun or independent computational validation of the modeling algorithm.

## Key navigation
- `M20_inner_crossfit_2026-10-16/README_FINAL.md`: original final handoff description.
- `M20_inner_crossfit_2026-10-16/MANIFEST.tsv`: source hash/size manifest for 106 payloads.
- `M20_inner_crossfit_2026-10-16/output_audit/primary_fold_stratified_summary.tsv`: primary point estimates.
- `M20_inner_crossfit_2026-10-16/tables/model/redesign/primary_estimand_aligned/`: conditional bootstrap records.
- `M20_inner_crossfit_2026-10-16/results/model/nested_cv/paired_oof_predictions.tsv`: 3,520 held-out predictions.
- `M20_inner_crossfit_2026-10-16/results/model/redesign/frozen_incremental_joint_model.rds`: frozen deployment object.
- `M20_inner_crossfit_2026-10-16/final_audit/VALIDATION.tsv`: run-level validation summary.
- `MANIFEST_SHA256.tsv`: all source files and newly added documentation except this manifest.

Before submission, supply this newly reissued S25 alongside the Main manuscript and Supplementary DOCX or deposit the file in the designated repository and ensure its URL is correct. This packaging alone does not prove a repository upload occurred.
