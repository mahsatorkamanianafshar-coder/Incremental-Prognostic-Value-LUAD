# Completed inner crossfit downstream audit
Date 2026-10-16
Primary C-index CI uses the repeat-wise fold-stratified patient-cluster bootstrap in tables/model/redesign/primary_estimand_aligned.
Script 19 bootstrap outputs are secondary patient-averaged OOF-ensemble estimates and must not be labeled as the primary estimand CI.
Bootstrap is conditional on already fitted OOF predictions; the entire modeling pipeline was not refitted inside each replicate.
Final model: none_linear alpha 0.25 lambda.min lambda 0.0904292498840317 genes 10
Selected genes: CCNB1, KIF14, GTSE1, FAM83A, CCNA2, CENPF, KIF20A, PRKCE, CDKN3, TFAP2A
External outputs were regenerated with the new isolated frozen model. C-index and 102-point IBS were independently reproduced from frozen LPs, baselines and calibration slopes. External IBS uses days 30-1825; no claim of a 30-730-day S37 analysis is made.
The original script-18 AUDIT_REPORT in output_audit describes that earlier stage; this final audit supersedes its statement that bootstrap/refit/external work had not yet occurred.
