suppressPackageStartupMessages({library(survival);library(dplyr)})
root <- "C:/tekyazar"
run <- file.path(root,"sensitivity_runs/M20_inner_crossfit_corrective_2026-10-15_v1")
out <- file.path(run,"output_audit")
dir.create(out,showWarnings=FALSE)
read <- function(p) read.delim(p,check.names=FALSE)
w <- function(x,n) write.table(x,file.path(out,n),sep="\t",quote=FALSE,row.names=FALSE,na="NA")
source(file.path(run,"scripts/lib_incremental_redesign.R"))
z <- read(file.path(run,"results/model/nested_cv/paired_oof_predictions.tsv"))
base <- read(file.path(root,"handoff/M20_fold_stratified_clinical_selection_2026-09-11_v1_stage/results/model/nested_cv/paired_oof_predictions.tsv"))
stopifnot(nrow(z)==3520L,length(unique(z$patient_id))==352L,all(table(z$repetition)==352L),
 !anyDuplicated(z[c("repetition","patient_id")]),all(dim(table(z$repetition,z$outer_fold))==c(10,5)))
lpcols <- c("clinical_lp","gene_lp","combined_lp","clinical_lp_raw_unscaled","gene_lp_raw_unscaled","combined_lp_raw_unscaled")
stopifnot(all(vapply(z[lpcols],function(x)all(is.finite(x)),logical(1))))
join <- merge(z,base,by=c("repetition","outer_fold","patient_id"),suffixes=c(".new",".S25"))
stopifnot(nrow(join)==3520L,all(join$OS_time.new==join$OS_time.S25),all(join$OS_event.new==join$OS_event.S25))
inner <- read(file.path(run,"tables/model/redesign/inner_train_only_specification_selection.tsv"))
stopifnot(nrow(inner)==1250L,sum(inner$selected)==250L,
 all(table(inner$repetition[inner$selected],inner$outer_fold[inner$selected])==5L))
outer <- read(file.path(run,"tables/model/redesign/clinical_specification_inner_selection.tsv"))
stopifnot(nrow(outer)==250L,sum(outer$selected)==50L)
cp <- readRDS(file.path(run,"results/model/redesign/nested_cv_outer_fold_checkpoint_inner_crossfit_v1.rds"))
stopifnot(length(cp$completed_outer_keys)==50L,cp$imputations==20L,cp$crossfit_rule=="inner_training_subcv_v1")
dense <- readRDS(file.path(run,"results/model/redesign/dense_oof_survival_predictions.rds"))
stopifnot(length(dense$time_grid)==102L,length(dense$rows)==50L,all(diff(dense$time_grid)>0))
for(obj in dense$rows)for(m in c("clinical","gene","combined")){
 a<-obj[[m]]
 stopifnot(nrow(a)==length(obj$patient_id),ncol(a)==102L,all(is.finite(a)),all(a>=0 & a<=1),all(apply(a,1,function(v)all(diff(v)<=1e-12))))
}
cvalue <- function(d,column,stratified=TRUE){
 d$score<-d[[column]]
 f<-if(stratified) concordance(Surv(OS_time,OS_event)~score+strata(outer_fold),data=d,reverse=TRUE) else concordance(Surv(OS_time,OS_event)~score,data=d,reverse=TRUE)
 f
}
models<-c(Clinical_only="clinical_lp",Gene_only="gene_lp",Combined="combined_lp")
rows<-list();foldrows<-list()
for(variant in c("corrected_S25","inner_crossfit")){
 data<-if(variant=="corrected_S25")base else z
 for(r in 1:10)for(m in names(models)){
  d<-data[data$repetition==r,];column<-models[[m]]
  f<-cvalue(d,column)
  fr<-lapply(1:5,function(k){a<-d[d$outer_fold==k,];v<-cvalue(a,column,FALSE);ct<-v$count;data.frame(variant=variant,repetition=r,outer_fold=k,model=m,C_index=v$concordance,comparable_pairs=sum(ct[c("concordant","discordant","tied.x")]))})
  fr<-bind_rows(fr);stopifnot(abs(weighted.mean(fr$C_index,fr$comparable_pairs)-f$concordance)<1e-12)
  foldrows[[length(foldrows)+1L]]<-fr
  rawcol<-paste0(column,"_raw_unscaled")
  rows[[length(rows)+1L]]<-data.frame(variant=variant,repetition=r,model=m,fold_stratified_C=f$concordance,raw_fold_stratified_C=if(rawcol %in% names(d))cvalue(d,rawcol)$concordance else NA_real_)
 }
}
reps<-bind_rows(rows);w(reps,"repeat_level_fold_stratified_cindex.tsv");w(bind_rows(foldrows),"fold_level_concordance.tsv")
delta<-merge(reps[reps$model=="Clinical_only",c("variant","repetition","fold_stratified_C")],reps[reps$model=="Combined",c("variant","repetition","fold_stratified_C")],by=c("variant","repetition"),suffixes=c("_clinical","_combined"))
delta$delta_C<-delta$fold_stratified_C_combined-delta$fold_stratified_C_clinical
w(delta,"repeat_level_delta_cindex.tsv")
summary<-delta %>% group_by(variant) %>% summarise(clinical_C=mean(fold_stratified_C_clinical),combined_C=mean(fold_stratified_C_combined),repeat_SD_delta_C=sd(delta_C),delta_C=mean(delta_C),.groups="drop")
w(summary,"primary_fold_stratified_summary.tsv")
# Recompute complete IPCW Brier curves from saved fold-frozen probabilities.
brierrows<-list();ibsrows<-list()
saved<-read(file.path(run,"tables/model/redesign/nested_model_metrics_long.tsv"))
for(r in 1:10){
 d<-z[z$repetition==r,]
 objects<-dense$rows[vapply(dense$rows,function(a)a$repetition==r,logical(1))]
 for(m in names(models)){
  mm<-c(Clinical_only="clinical",Gene_only="gene",Combined="combined")[[m]]
  a<-matrix(NA_real_,nrow(d),102)
  for(obj in objects)a[match(obj$patient_id,d$patient_id),]<-obj[[mm]]
  bs<-vapply(seq_along(dense$time_grid),function(j)ipcw_brier_redesign(d$OS_time,d$OS_event,a[,j],dense$time_grid[j]),numeric(1))
  ibs<-sum(diff(dense$time_grid)*(head(bs,-1)+tail(bs,-1))/2)/diff(range(dense$time_grid))
  expected<-saved$IBS[saved$repetition==r & saved$model==m]
  stopifnot(length(expected)==1L,abs(ibs-expected)<1e-12)
  brierrows[[length(brierrows)+1L]]<-data.frame(repetition=r,model=m,time_days=dense$time_grid,IPCW_Brier=bs)
  ibsrows[[length(ibsrows)+1L]]<-data.frame(repetition=r,model=m,IBS=ibs,original_IBS=expected,abs_difference=abs(ibs-expected))
 }
}
w(bind_rows(brierrows),"IPCW_Brier_102_time_points.tsv");w(bind_rows(ibsrows),"IBS_reproduction.tsv")
w(as.data.frame(table(outer$clinical_specification[outer$selected])),"outer_clinical_selection_frequency.tsv")
w(as.data.frame(table(inner$clinical_specification[inner$selected])),"inner_training_clinical_selection_frequency.tsv")
w(data.frame(check=c("OOF_rows","patients","outer_analyses","inner_selected_specifications","cache_files","all_LP_finite","dense_survival_valid","IBS_reproduced"),result=c(3520,352,50,250,length(list.files(file.path(run,"results/model/redesign/fold_feature_discovery_cache_inner_crossfit_v1"))),TRUE,TRUE,TRUE)),"VALIDATION.tsv")
capture.output(sessionInfo(),file=file.path(out,"sessionInfo_audit.txt"))
report<-c("# Corrective inner crossfit output audit",paste("Audit date:",Sys.Date()),
 "All 50 outer analyses completed. OOF structure, 1250 inner specification rows/250 selections, 102-point survival arrays and IPCW IBS reproduction passed.",
 "Primary performance is fold-stratified comparable-pair-weighted concordance averaged over ten repeats. The supplied script's pooled C-index output is retained as a secondary diagnostic, not the primary estimate.",
 capture.output(print(as.data.frame(summary),digits=8)),
 "The comparison uses corrected Sept 11 S25 with matching patient/repeat/fold/outcome identities. No new bootstrap CI, final refit, external evaluation or deployment model was generated.",
 "Console reports 50 or more warnings without retaining a complete final warnings() list. The logged DESeq2 dispersion fallback is preserved; successful structural checks do not establish that every unrecorded warning was benign.")
writeLines(report,file.path(out,"AUDIT_REPORT.md"))
cat("AUDIT PASS\n");print(summary)
