required <- c("SummarizedExperiment","DESeq2","tidyverse","survival","glmnet","timeROC")
for (p in required) {
  if (!requireNamespace(p, quietly=TRUE)) stop("Missing required package: ",p)
  cat(p,as.character(packageVersion(p)),"\n")
}
for (p in c("scripts/18_inner_crossfit_corrective_sensitivity.R","scripts/lib_analysis_rules.R",
            "scripts/lib_incremental_redesign.R","scripts/lib_outer_fold_feature_discovery.R")) {
  parse(p); cat("PARSE PASS",p,"\n")
}
suppressPackageStartupMessages(library(tidyverse))
source("scripts/lib_analysis_rules.R")
source("scripts/lib_incremental_redesign.R")
tr <- prepare_raw_clinical_redesign(read.delim("results/model/risk_scores_training.tsv",check.names=FALSE))
te <- prepare_raw_clinical_redesign(read.delim("results/model/risk_scores_testing.tsv",check.names=FALSE))
stopifnot(nrow(tr)==352L,sum(tr$OS_event)==127L,nrow(te)==152L,sum(te$OS_event)==55L,
          length(intersect(tr$patient_id,te$patient_id))==0L)
stopifnot(Sys.getenv("REDESIGN_IMPUTATIONS")=="20",Sys.getenv("REDESIGN_REPEATS")=="10",
          Sys.getenv("REDESIGN_CROSSFIT_ISOLATED_RUN")=="YES",
          Sys.getenv("REDESIGN_REQUIRE_EXISTING_DISCOVERY_CACHE")=="false")
cat("PREFLIGHT PASS: packages, syntax, cohorts, settings\n")
capture.output(sessionInfo(),file="sessionInfo_preflight.txt")
