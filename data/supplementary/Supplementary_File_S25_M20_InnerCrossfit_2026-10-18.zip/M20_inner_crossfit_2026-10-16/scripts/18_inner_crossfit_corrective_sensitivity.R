# ============================================================
# Corrective inner-training-only clinical-specification selection / 352-patient development
# ============================================================

suppressPackageStartupMessages({
  library(SummarizedExperiment)
  library(DESeq2)
  library(tidyverse)
  library(survival)
  library(glmnet)
  library(timeROC)
})
source("scripts/lib_analysis_rules.R")
source("scripts/lib_incremental_redesign.R")
source("scripts/lib_outer_fold_feature_discovery.R")

# REQUIRED: run inside an isolated copy of the full research project.
# Historical files and the frozen manuscript must not be overwritten.
if (Sys.getenv("REDESIGN_CROSSFIT_ISOLATED_RUN", "") != "YES") {
  stop("STOP: isolate the study project and set REDESIGN_CROSSFIT_ISOLATED_RUN=YES")
}
if (file.exists("results/model/nested_cv/paired_oof_predictions.tsv")) {
  stop("STOP: existing paired predictions detected. Use a clean isolated output directory.")
}
dir.create("results/model/redesign", recursive = TRUE, showWarnings = FALSE)
dir.create("results/model/nested_cv", recursive = TRUE, showWarnings = FALSE)
dir.create("tables/model/redesign", recursive = TRUE, showWarnings = FALSE)
dir.create("tables/model", recursive = TRUE, showWarnings = FALSE)

repeats <- as.integer(Sys.getenv("REDESIGN_REPEATS", "10"))
outer_folds <- 5L
inner_folds <- 5L
imputations <- as.integer(Sys.getenv("REDESIGN_IMPUTATIONS", "5"))
match_ranking_to_comparator <- identical(
  tolower(Sys.getenv("REDESIGN_MATCH_RANKING_TO_COMPARATOR", "false")), "true"
)
gene_pooling_method <- Sys.getenv(
  "REDESIGN_GENE_POOLING_METHOD", "custom_normal"
)
stopifnot(gene_pooling_method %in% c("custom_normal", "rubin_barnard_rubin"))
feature_transform <- Sys.getenv("REDESIGN_FEATURE_TRANSFORM", "s_score")
stopifnot(feature_transform %in% c("s_score", "yugene"))
clinical_tuning_rule <- tolower(Sys.getenv(
  "REDESIGN_CLINICAL_TUNING_RULE", "pooled"
))
stopifnot(clinical_tuning_rule == "fold_stratified")
stopifnot(Sys.getenv("REDESIGN_PACK_PMM_RULE") == "smoking_constrained")
require_existing_discovery_cache <- identical(
  tolower(Sys.getenv("REDESIGN_REQUIRE_EXISTING_DISCOVERY_CACHE", "false")),
  "true"
)
alpha_grid <- c(0, 0.25, 0.50, 0.75, 1.00)
candidate_limits <- 20L
clinical_specs <- c(
  "pack_linear", "none_linear", "ever_linear",
  "pack_nonlinear", "none_nonlinear"
)
horizons <- c(365, 1095, 1825)
ibs_grid <- sort(unique(c(seq(30, 1825, length.out = 100L), horizons)))

if (repeats < 1L || repeats > 10L || imputations < 2L) {
  stop("Invalid redesign repeat/imputation settings.")
}

train_source <- read.delim(
  "results/model/risk_scores_training.tsv",
  stringsAsFactors = FALSE, check.names = FALSE
)
secondary_source <- read.delim(
  "results/model/risk_scores_testing.tsv",
  stringsAsFactors = FALSE, check.names = FALSE
)
development <- prepare_raw_clinical_redesign(train_source)
secondary <- prepare_raw_clinical_redesign(secondary_source)
stopifnot(nrow(development) == 352L, sum(development$OS_event) == 127L)
stopifnot(nrow(secondary) == 152L, sum(secondary$OS_event) == 55L)

cohort_roles <- data.frame(
  split_label = c("Training", "Testing"),
  analysis_role = c(
    "development_cohort",
    "previously_observed_secondary_internal_validation_cohort"
  ),
  n = c(nrow(development), nrow(secondary)),
  events = c(sum(development$OS_event), sum(secondary$OS_event)),
  stringsAsFactors = FALSE
)
write.table(
  cohort_roles, "tables/model/redesign/cohort_role_lock.tsv",
  sep = "\t", quote = FALSE, row.names = FALSE
)

# Build the unchanged frozen fifteen-reference-gene transformation directly
# from the TCGA count object, retaining one lexicographically smallest primary
# tumor barcode per patient.
luad_exp <- readRDS("data_raw/TCGA_LUAD_STAR_counts_SE.rds")
count_matrix <- if ("unstranded" %in% assayNames(luad_exp))
  assay(luad_exp, "unstranded") else assay(luad_exp, 1)
sample_info <- as.data.frame(colData(luad_exp))
gene_info <- as.data.frame(rowData(luad_exp))
sample_info$sample_barcode <- rownames(sample_info)
sample_info$patient_id <- substr(sample_info$sample_barcode, 1, 12)
tumor_info <- select_one_sample_per_patient_type(sample_info) %>%
  filter(sample_type == "Primary Tumor") %>%
  arrange(patient_id, sample_barcode)
all_required_patients <- c(development$patient_id, secondary$patient_id)
tumor_info <- tumor_info %>% filter(patient_id %in% all_required_patients)
stopifnot(all(all_required_patients %in% tumor_info$patient_id))

tumor_counts <- round(count_matrix[, tumor_info$sample_barcode, drop = FALSE])
storage.mode(tumor_counts) <- "integer"
library_size <- colSums(tumor_counts)
log_cpm <- log2(sweep(tumor_counts, 2, library_size, "/") * 1e6 + 1)
gene_symbols <- toupper(trimws(as.character(gene_info$gene_name)))
names(gene_symbols) <- rownames(gene_info)
reference_genes <- c(
  "ACTB", "B2M", "GAPDH", "GUSB", "HMBS", "HPRT1", "PGK1",
  "PPIA", "RPL13A", "RPLP0", "SDHA", "TBP", "TFRC", "UBC", "YWHAZ"
)
reference_ids <- vapply(reference_genes, function(symbol) {
  hit <- names(gene_symbols)[gene_symbols == symbol]
  if (length(hit)) hit[1] else NA_character_
}, character(1))
stopifnot(!anyNA(reference_ids))
reference_matrix <- log_cpm[reference_ids, , drop = FALSE]
rownames(reference_matrix) <- reference_genes

yugene_matrix <- NULL
if (feature_transform == "yugene") {
  gene_level_log_cpm <- aggregate_symbol_matrix_redesign(
    log_cpm[, tumor_info$sample_barcode, drop = FALSE], gene_symbols
  )
  yugene_matrix <- yugene_transform_redesign(gene_level_log_cpm)
  rm(gene_level_log_cpm)
  gc()
}
write.table(data.frame(
  feature_transform = feature_transform,
  implementation = if (feature_transform == "yugene")
    "exact_archived_CRAN_YuGene_1.1.6_algorithm" else
    "16_level_reference_panel_percentile_S_score",
  duplicate_symbol_rule = if (feature_transform == "yugene")
    "arithmetic_mean_before_transform" else "first_annotated_Ensembl_row",
  feature_universe_genes = if (feature_transform == "yugene")
    nrow(yugene_matrix) else length(reference_genes),
  outcome_used = FALSE, stringsAsFactors = FALSE
), "tables/model/redesign/feature_transformation_audit.tsv",
sep = "\t", quote = FALSE, row.names = FALSE)

build_features <- function(gene_names, patient_ids) {
  gene_names <- unique(toupper(as.character(gene_names)))
  if (feature_transform == "yugene") {
    gene_names <- intersect(gene_names, rownames(yugene_matrix))
    barcodes <- tumor_info$sample_barcode[match(patient_ids, tumor_info$patient_id)]
    return(t(yugene_matrix[gene_names, barcodes, drop = FALSE]))
  }
  gene_ids <- vapply(gene_names, function(symbol) {
    hit <- names(gene_symbols)[gene_symbols == symbol]
    if (length(hit)) hit[1] else NA_character_
  }, character(1))
  keep <- !is.na(gene_ids)
  gene_names <- gene_names[keep]; gene_ids <- gene_ids[keep]
  sample_index <- match(patient_ids, tumor_info$patient_id)
  barcodes <- tumor_info$sample_barcode[sample_index]
  refs <- reference_matrix[, barcodes, drop = FALSE]
  out <- t(vapply(seq_along(gene_ids), function(i) {
    (1 + colSums(sweep(refs, 2, log_cpm[gene_ids[i], barcodes], FUN = "<="))) /
      (nrow(refs) + 1)
  }, numeric(length(barcodes))))
  rownames(out) <- gene_names; colnames(out) <- patient_ids
  t(out)
}

# V1 fingerprinting prevents patient-ID-only stale-cache reuse.
# The original 300 caches are deliberately not loaded.
count_file <- "data_raw/TCGA_LUAD_STAR_counts_SE.rds"
discovery_lib_file <- "scripts/lib_outer_fold_feature_discovery.R"
analysis_lib_file <- "scripts/lib_analysis_rules.R"
runner_file <- "scripts/18_inner_crossfit_corrective_sensitivity.R"
stopifnot(all(file.exists(c(count_file, discovery_lib_file,
                            analysis_lib_file, runner_file))))
discovery_fingerprint <- paste(
  unname(tools::md5sum(c(count_file, discovery_lib_file,
                          analysis_lib_file, runner_file))),
  collapse = "_"
)
cache_dir <- "results/model/redesign/fold_feature_discovery_cache_inner_crossfit_v1"
dir.create(cache_dir, recursive = TRUE, showWarnings = FALSE)
discovery_audit_rows <- list()

cached_top500 <- function(patient_ids, label) {
  patient_ids <- sort(unique(patient_ids))
  key <- paste(patient_ids, collapse = "|")
  checksum <- sprintf("%08x", as.integer(sum(
    utf8ToInt(key) * rep(seq_len(997L), length.out = nchar(key))
  ) %% .Machine$integer.max))
  path <- file.path(cache_dir, paste0(
    label, "_", checksum, "_", substr(discovery_fingerprint, 1L, 12L), ".rds"
  ))
  if (file.exists(path)) {
    cached <- readRDS(path)
    if (identical(cached$patient_ids, patient_ids) &&
        identical(cached$discovery_fingerprint, discovery_fingerprint) &&
        identical(cached$top_deg_n, 500L)) return(cached$result)
  }
  if (require_existing_discovery_cache) {
    stop(
      "Required fold-discovery cache is absent or does not match patient IDs: ",
      path
    )
  }
  result <- discover_fold_top500_deg(
    count_matrix, sample_info, gene_info, patient_ids, top_deg_n = 500L
  )
  saveRDS(list(
    patient_ids = patient_ids, discovery_fingerprint = discovery_fingerprint,
    top_deg_n = 500L, result = result
  ), path, compress = "xz")
  result
}

oof_rows <- list(); dense_rows <- list(); tuning_rows <- list()
clinical_tuning_rows <- list(); inner_spec_tuning_rows <- list(); selection_rows <- list(); screen_rows <- list()
all_gene_rows <- list()
run_index <- 1L
checkpoint_path <- "results/model/redesign/nested_cv_outer_fold_checkpoint_inner_crossfit_v1.rds"
completed_outer_keys <- character(0)
if (file.exists(checkpoint_path)) {
  checkpoint <- readRDS(checkpoint_path)
  stopifnot(
    identical(checkpoint$crossfit_rule, "inner_training_subcv_v1"),
    identical(checkpoint$discovery_fingerprint, discovery_fingerprint),
    checkpoint$repeats == repeats,
    checkpoint$outer_folds == outer_folds,
    checkpoint$inner_folds == inner_folds,
    checkpoint$imputations == imputations,
    identical(checkpoint$gene_pooling_method, gene_pooling_method),
    identical(checkpoint$feature_transform, feature_transform),
    identical(checkpoint$clinical_tuning_rule, clinical_tuning_rule),
    identical(checkpoint$match_ranking_to_comparator,
              match_ranking_to_comparator)
  )
  oof_rows <- checkpoint$oof_rows
  dense_rows <- checkpoint$dense_rows
  tuning_rows <- checkpoint$tuning_rows
  clinical_tuning_rows <- checkpoint$clinical_tuning_rows
  inner_spec_tuning_rows <- checkpoint$inner_spec_tuning_rows
  selection_rows <- checkpoint$selection_rows
  screen_rows <- checkpoint$screen_rows
  all_gene_rows <- checkpoint$all_gene_rows
  discovery_audit_rows <- checkpoint$discovery_audit_rows
  completed_outer_keys <- checkpoint$completed_outer_keys
  run_index <- length(oof_rows) + 1L
  cat("Resuming after", length(completed_outer_keys), "completed outer folds.\n")
}

for (repeat_id in seq_len(repeats)) {
  outer_id <- make_stratified_folds_redesign(
    development$OS_event, outer_folds, 10000L + repeat_id
  )
  for (outer_fold in seq_len(outer_folds)) {
    outer_key <- sprintf("r%02d_o%02d", repeat_id, outer_fold)
    if (outer_key %in% completed_outer_keys) next
    cat("Redesign repeat", repeat_id, "outer fold", outer_fold, "\n")
    assessment_index <- which(outer_id == outer_fold)
    analysis_index <- which(outer_id != outer_fold)
    analysis_raw <- development[analysis_index, , drop = FALSE]
    assessment_raw <- development[assessment_index, , drop = FALSE]
    inner_id <- make_stratified_folds_redesign(
      analysis_raw$OS_event, inner_folds,
      20000L + repeat_id * 100L + outer_fold
    )

    outer_discovery <- cached_top500(
      analysis_raw$patient_id,
      sprintf("r%02d_o%02d_outer", repeat_id, outer_fold)
    )
    discovery_audit_rows[[length(discovery_audit_rows) + 1L]] <-
      outer_discovery$summary %>%
      mutate(repetition = repeat_id, outer_fold = outer_fold,
             inner_fold = NA_integer_, partition = "outer_analysis",
             .before = 1)
    candidate_genes <- unique(toupper(outer_discovery$top500_deg$gene_name))
    x_analysis <- build_features(candidate_genes, analysis_raw$patient_id)
    x_assessment <- build_features(candidate_genes, assessment_raw$patient_id)
    common_genes <- intersect(colnames(x_analysis), colnames(x_assessment))
    x_analysis <- x_analysis[, common_genes, drop = FALSE]
    x_assessment <- x_assessment[, common_genes, drop = FALSE]

    clinical_tuning <- tune_clinical_spec_redesign(
      analysis_raw, inner_id, clinical_specs,
      30000L + repeat_id * 100L + outer_fold
    )
    selected_spec <- clinical_tuning$selected
    clinical_tuning_rows[[run_index]] <- clinical_tuning$table %>%
      mutate(repetition = repeat_id, outer_fold = outer_fold,
             selected = clinical_specification == selected_spec, .before = 1)

    # In the canonical analysis the adjusted ranking used pack_linear. The
    # opt-in sensitivity instead matches the screen to the clinical comparator
    # selected in this outer-analysis partition.
    ranking_spec <- if (match_ranking_to_comparator) selected_spec else "pack_linear"
    adjusted_designs <- lapply(seq_len(imputations), function(m) {
      clinical_design_redesign(
        analysis_raw, analysis_raw, ranking_spec,
        40000L + repeat_id * 1000L + outer_fold * 10L + m
      )$train
    })
    univariate_screen <- pool_gene_screen_redesign(x_analysis, analysis_raw)
    adjusted_screen <- pool_gene_screen_redesign(
      x_analysis, analysis_raw, adjusted_designs
    )
    screen_rows[[length(screen_rows) + 1L]] <- bind_rows(
      univariate_screen %>% mutate(screen = "univariate"),
      adjusted_screen %>% mutate(
        screen = "clinical_adjusted",
        ranking_clinical_specification = ranking_spec
      )
    ) %>% mutate(repetition = repeat_id, outer_fold = outer_fold, .before = 1)

    survival_genes <- univariate_screen$gene_name[
      is.finite(univariate_screen$pvalue) & univariate_screen$pvalue < 0.05
    ]
    ranked_univariate <- survival_genes
    ranked_adjusted <- adjusted_screen$gene_name[
      adjusted_screen$gene_name %in% survival_genes &
        is.finite(adjusted_screen$pvalue)
    ]

    # End-to-end nesting: each inner-training partition reruns paired DEG,
    # strict Top-500 discovery, survival screens, training-only imputation,
    # adjusted ranking, standardization, and alpha/lambda fitting.
    inner_gene <- list(); inner_combined <- list()
    for (inner_fold in seq_len(inner_folds)) {
      inner_train_index <- which(inner_id != inner_fold)
      inner_valid_index <- which(inner_id == inner_fold)
      inner_train <- analysis_raw[inner_train_index, , drop = FALSE]
      inner_valid <- analysis_raw[inner_valid_index, , drop = FALSE]
      inner_discovery <- cached_top500(
        inner_train$patient_id,
        sprintf("r%02d_o%02d_i%02d", repeat_id, outer_fold, inner_fold)
      )
      discovery_audit_rows[[length(discovery_audit_rows) + 1L]] <-
        inner_discovery$summary %>%
        mutate(repetition = repeat_id, outer_fold = outer_fold,
               inner_fold = inner_fold, partition = "inner_training",
               .before = 1)
      inner_candidates <- unique(toupper(
        inner_discovery$top500_deg$gene_name
      ))
      x_inner_train <- build_features(
        inner_candidates, inner_train$patient_id
      )
      x_inner_valid <- build_features(
        inner_candidates, inner_valid$patient_id
      )
      inner_univariate <- pool_gene_screen_redesign(
        x_inner_train, inner_train
      )
      # Corrected training-only clinical selection: the held-out inner
      # validation outcomes are NEVER provided to the selector. This adds
      # a clinical sub-CV over inner_train only for EACH inner fold.
      inner_subfold_id <- make_stratified_folds_redesign(
        inner_train$OS_event, 5L,
        1100000L + repeat_id * 10000L + outer_fold * 100L + inner_fold
      )
      inner_spec_tuning <- tune_clinical_spec_redesign(
        inner_train, inner_subfold_id, clinical_specs,
        1200000L + repeat_id * 10000L + outer_fold * 100L + inner_fold
      )
      inner_selected_spec <- inner_spec_tuning$selected
      inner_spec_tuning_rows[[length(inner_spec_tuning_rows) + 1L]] <-
        inner_spec_tuning$table %>%
        mutate(repetition = repeat_id, outer_fold = outer_fold,
               inner_fold = inner_fold,
               selected = clinical_specification == inner_selected_spec,
               .before = 1)
      # Keep the fixed pack_linear screen unchanged for the locked analysis.
      # Comparator-matched sensitivity can use ONLY the inner training choice.
      inner_ranking_spec <- if (match_ranking_to_comparator) {
        inner_selected_spec
      } else "pack_linear"
      inner_adjusted_designs <- lapply(seq_len(imputations), function(m) {
        clinical_design_redesign(
          inner_train, inner_train, inner_ranking_spec,
          700000L + repeat_id * 10000L + outer_fold * 100L +
            inner_fold * 10L + m
        )$train
      })
      inner_adjusted <- pool_gene_screen_redesign(
        x_inner_train, inner_train, inner_adjusted_designs
      )
      inner_survival_genes <- inner_univariate$gene_name[
        is.finite(inner_univariate$pvalue) & inner_univariate$pvalue < 0.05
      ]
      inner_gene[[as.character(inner_fold)]] <-
        evaluate_inner_enet_redesign(
          x_inner_train, x_inner_valid,
          inner_survival_genes,
          inner_train, inner_valid, alpha_grid,
          clinical_specification = NULL,
          seed = 800000L + repeat_id * 10000L +
            outer_fold * 100L + inner_fold,
          max_genes = 15L, allow_zero_genes = FALSE, horizons = horizons
        )
      inner_combined[[as.character(inner_fold)]] <-
        evaluate_inner_enet_redesign(
          x_inner_train, x_inner_valid,
          inner_adjusted$gene_name[
            inner_adjusted$gene_name %in% inner_survival_genes &
              is.finite(inner_adjusted$pvalue)
          ],
          inner_train, inner_valid, alpha_grid,
          clinical_specification = inner_selected_spec,
          seed = 900000L + repeat_id * 10000L +
            outer_fold * 100L + inner_fold,
          max_genes = 15L, allow_zero_genes = TRUE, horizons = horizons
        )
    }
    tuned_gene <- select_end_to_end_tuning_redesign(
      inner_gene, analysis_raw, inner_id, horizons
    )
    tuned_combined <- select_end_to_end_tuning_redesign(
      inner_combined, analysis_raw, inner_id, horizons
    )
    tuning_rows[[length(tuning_rows) + 1L]] <- bind_rows(
      tuned_gene$table %>% mutate(model = "Gene_only"),
      tuned_combined$table %>% mutate(model = "Combined")
    ) %>% mutate(
      repetition = repeat_id, outer_fold = outer_fold,
      selected = (model == "Gene_only" & fit_key == tuned_gene$selected$fit_key) |
        (model == "Combined" & fit_key == tuned_combined$selected$fit_key),
      .before = 1
    )

    gene_fit <- refit_selected_enet_redesign(
      tuned_gene$selected, x_analysis, x_assessment, ranked_univariate,
      analysis_raw, inner_id
    )
    gene_survival <- survival_from_lp_redesign(
      analysis_raw$OS_time, analysis_raw$OS_event,
      gene_fit$train_lp, gene_fit$test_lp, ibs_grid
    )
    gene_test_score <- standardize_lp_redesign(
      gene_fit$train_lp, gene_fit$test_lp
    )

    clinical_lp <- combined_lp <- rep(0, nrow(assessment_raw))
    clinical_lp_raw_unscaled <- combined_lp_raw_unscaled <-
      rep(0, nrow(assessment_raw))
    clinical_survival <- combined_survival <-
      matrix(0, nrow = nrow(assessment_raw), ncol = length(ibs_grid))
    combined_betas <- list()
    for (m in seq_len(imputations)) {
      design <- clinical_design_redesign(
        analysis_raw, assessment_raw, selected_spec,
        60000L + repeat_id * 1000L + outer_fold * 10L + m
      )
      clinical_fit <- cox_matrix_predict_redesign(
        design$train, analysis_raw$OS_time, analysis_raw$OS_event, design$test
      )
      combined_fit <- refit_selected_enet_redesign(
        tuned_combined$selected, x_analysis, x_assessment, ranked_adjusted,
        analysis_raw, inner_id, design$train, design$test
      )
      clinical_lp <- clinical_lp + standardize_lp_redesign(
        clinical_fit$train_lp, clinical_fit$test_lp
      ) / imputations
      combined_lp <- combined_lp + standardize_lp_redesign(
        combined_fit$train_lp, combined_fit$test_lp
      ) / imputations
      # Preserve the direct outer-assessment linear predictors before any
      # fold-wise centering/scaling. These are required for the M8 diagnostic
      # pooled C-index and are never substituted by back-transformation of the
      # standardized OOF values.
      clinical_lp_raw_unscaled <- clinical_lp_raw_unscaled +
        clinical_fit$test_lp / imputations
      combined_lp_raw_unscaled <- combined_lp_raw_unscaled +
        combined_fit$test_lp / imputations
      clinical_survival <- clinical_survival + survival_from_lp_redesign(
        analysis_raw$OS_time, analysis_raw$OS_event,
        clinical_fit$train_lp, clinical_fit$test_lp, ibs_grid
      ) / imputations
      combined_survival <- combined_survival + survival_from_lp_redesign(
        analysis_raw$OS_time, analysis_raw$OS_event,
        combined_fit$train_lp, combined_fit$test_lp, ibs_grid
      ) / imputations
      combined_betas[[m]] <- combined_fit$beta
    }

    horizon_index <- match(horizons, ibs_grid)
    oof_rows[[run_index]] <- data.frame(
      repetition = repeat_id, outer_fold = outer_fold,
      patient_id = assessment_raw$patient_id,
      OS_time = assessment_raw$OS_time, OS_event = assessment_raw$OS_event,
      clinical_specification = selected_spec,
      clinical_lp = clinical_lp, gene_lp = gene_test_score,
      combined_lp = combined_lp,
      clinical_lp_raw_unscaled = clinical_lp_raw_unscaled,
      gene_lp_raw_unscaled = gene_fit$test_lp,
      combined_lp_raw_unscaled = combined_lp_raw_unscaled,
      clinical_surv_1y = clinical_survival[, horizon_index[1]],
      clinical_surv_3y = clinical_survival[, horizon_index[2]],
      clinical_surv_5y = clinical_survival[, horizon_index[3]],
      gene_surv_1y = gene_survival[, horizon_index[1]],
      gene_surv_3y = gene_survival[, horizon_index[2]],
      gene_surv_5y = gene_survival[, horizon_index[3]],
      combined_surv_1y = combined_survival[, horizon_index[1]],
      combined_surv_3y = combined_survival[, horizon_index[2]],
      combined_surv_5y = combined_survival[, horizon_index[3]],
      stringsAsFactors = FALSE
    )
    dense_rows[[run_index]] <- list(
      repetition = repeat_id, patient_id = assessment_raw$patient_id,
      clinical = clinical_survival, gene = gene_survival,
      combined = combined_survival
    )
    selection_rows[[run_index]] <- bind_rows(
      data.frame(
        model = "Gene_only", gene_name = names(gene_fit$beta),
        coefficient = as.numeric(gene_fit$beta), stringsAsFactors = FALSE
      ) %>% filter(coefficient != 0),
      data.frame(
        model = "Combined", gene_name = names(combined_betas[[1]]),
        coefficient = as.numeric(combined_betas[[1]]), stringsAsFactors = FALSE
      ) %>% filter(gene_name %in% colnames(x_analysis), coefficient != 0)
    ) %>% mutate(repetition = repeat_id, outer_fold = outer_fold, .before = 1)

    # Preserve every fold-specific Top-500 gene, including genes that were
    # screened out, not admitted to the Top-20 input, or shrunk to zero. This
    # makes all-gene stability and exact coefficient-sign frequencies
    # auditable without inferring signs from marginal Cox coefficients.
    make_all_gene_audit <- function(model_name, input_genes, beta) {
      genes <- colnames(x_analysis)
      coefficient <- rep(0, length(genes)); names(coefficient) <- genes
      common_beta <- intersect(genes, names(beta))
      coefficient[common_beta] <- as.numeric(beta[common_beta])
      data.frame(
        repetition = repeat_id,
        outer_fold = outer_fold,
        model = model_name,
        gene_name = genes,
        screened_in_fold_top500 = TRUE,
        univariate_pvalue = univariate_screen$pvalue[
          match(genes, univariate_screen$gene_name)
        ],
        adjusted_pvalue = adjusted_screen$pvalue[
          match(genes, adjusted_screen$gene_name)
        ],
        passed_univariate_p05 = genes %in% survival_genes,
        survival_rank = match(genes, ranked_univariate),
        adjusted_rank = match(genes, ranked_adjusted),
        admitted_to_top20 = genes %in% input_genes,
        coefficient = as.numeric(coefficient),
        selected_nonzero = as.numeric(coefficient) != 0,
        coefficient_sign = case_when(
          as.numeric(coefficient) > 0 ~ "positive",
          as.numeric(coefficient) < 0 ~ "negative",
          TRUE ~ "zero"
        ),
        stringsAsFactors = FALSE
      )
    }
    all_gene_rows[[run_index]] <- bind_rows(
      make_all_gene_audit("Gene_only", gene_fit$genes, gene_fit$beta),
      make_all_gene_audit(
        "Combined", combined_fit$genes, combined_betas[[1]]
      )
    )
    run_index <- run_index + 1L
    completed_outer_keys <- c(completed_outer_keys, outer_key)
    saveRDS(list(
      crossfit_rule = "inner_training_subcv_v1",
      discovery_fingerprint = discovery_fingerprint,
      repeats = repeats, outer_folds = outer_folds, inner_folds = inner_folds,
      imputations = imputations,
      gene_pooling_method = gene_pooling_method,
      feature_transform = feature_transform,
      clinical_tuning_rule = clinical_tuning_rule,
      require_existing_discovery_cache = require_existing_discovery_cache,
      match_ranking_to_comparator = match_ranking_to_comparator,
      completed_outer_keys = completed_outer_keys,
      oof_rows = oof_rows, dense_rows = dense_rows,
      tuning_rows = tuning_rows,
      clinical_tuning_rows = clinical_tuning_rows,
      inner_spec_tuning_rows = inner_spec_tuning_rows,
      selection_rows = selection_rows, screen_rows = screen_rows,
      all_gene_rows = all_gene_rows,
      discovery_audit_rows = discovery_audit_rows
    ), checkpoint_path, compress = "gzip")
  }
}

oof <- bind_rows(oof_rows)
screens <- bind_rows(screen_rows)
tuning <- bind_rows(tuning_rows)
clinical_tuning <- bind_rows(clinical_tuning_rows)
inner_spec_tuning <- bind_rows(inner_spec_tuning_rows)
stopifnot(nrow(inner_spec_tuning) == repeats * outer_folds * inner_folds * length(clinical_specs))
selections <- bind_rows(selection_rows)
all_gene_coefficients <- bind_rows(all_gene_rows)

stopifnot(nrow(oof) == nrow(development) * repeats)
stopifnot(all(table(oof$repetition) == nrow(development)))

write.table(
  oof, "results/model/nested_cv/paired_oof_predictions.tsv",
  sep = "\t", quote = FALSE, row.names = FALSE
)
write.table(
  screens, "results/model/redesign/outer_fold_dual_gene_screens.tsv",
  sep = "\t", quote = FALSE, row.names = FALSE
)
write.table(
  tuning, "tables/model/elastic_net_alpha_lambda_selection.tsv",
  sep = "\t", quote = FALSE, row.names = FALSE
)
write.table(
  clinical_tuning, "tables/model/redesign/clinical_specification_inner_selection.tsv",
  sep = "\t", quote = FALSE, row.names = FALSE
)
write.table(
  inner_spec_tuning,
  "tables/model/redesign/inner_train_only_specification_selection.tsv",
  sep = "\t", quote = FALSE, row.names = FALSE
)
write.table(
  data.frame(
    rule = "inner_training_subcv_v1",
    discovery_fingerprint = discovery_fingerprint,
    runner_md5 = unname(tools::md5sum(runner_file)),
    clinical_tuning_rule = clinical_tuning_rule,
    feature_transform = feature_transform,
    pack_pmm_rule = Sys.getenv("REDESIGN_PACK_PMM_RULE"),
    stringsAsFactors = FALSE
  ),
  "tables/model/redesign/inner_crossfit_run_manifest.tsv",
  sep = "\t", quote = FALSE, row.names = FALSE
)
write.table(
  all_gene_coefficients,
  "results/model/redesign/outer_fold_all_gene_coefficients.tsv",
  sep = "\t", quote = FALSE, row.names = FALSE, na = "NA"
)
write.table(
  bind_rows(discovery_audit_rows),
  "results/model/nested_cv/end_to_end_fold_discovery_audit.tsv",
  sep = "\t", quote = FALSE, row.names = FALSE
)
# Preserve the complete 102-time-point, fold-frozen survival predictions.
# This is intentionally an RDS rather than a very large rectangular TSV: it
# permits paired patient-level bootstrap of IBS without refitting or
# approximating the survival curves from only the 1-, 3-, and 5-year values.
saveRDS(
  list(
    time_grid = ibs_grid,
    rows = dense_rows,
    development_patient_ids = development$patient_id,
    repeats = repeats,
    outer_folds = outer_folds,
    imputations = imputations
    , ranking_strategy = if (match_ranking_to_comparator) {
      "comparator_matched"
    } else "fixed_pack_linear"
    , pack_pmm_rule = Sys.getenv(
      "REDESIGN_PACK_PMM_RULE", "legacy_unconstrained"
    )
    , gene_pooling_method = gene_pooling_method
    , feature_transform = feature_transform
    , clinical_tuning_rule = clinical_tuning_rule
    , clinical_spec_inner_rule = "inner_training_subcv_v1"
    , discovery_fingerprint = discovery_fingerprint
    , require_existing_discovery_cache = require_existing_discovery_cache
  ),
  "results/model/redesign/dense_oof_survival_predictions.rds",
  compress = "xz"
)

selection_stability <- selections %>%
  group_by(model, gene_name) %>%
  summarise(
    selected_runs = n(), total_runs = repeats * outer_folds,
    selection_frequency = selected_runs / total_runs,
    median_coefficient = median(coefficient), .groups = "drop"
  ) %>% arrange(model, desc(selection_frequency), desc(abs(median_coefficient)))
write.table(
  selection_stability, "tables/model/gene_selection_stability.tsv",
  sep = "\t", quote = FALSE, row.names = FALSE
)

all_gene_stability <- all_gene_coefficients %>%
  group_by(model, gene_name) %>%
  summarise(
    total_outer_runs = repeats * outer_folds,
    screened_runs = n(),
    survival_p05_runs = sum(passed_univariate_p05),
    top20_input_runs = sum(admitted_to_top20),
    selected_runs = sum(selected_nonzero),
    positive_selected_runs = sum(coefficient > 0),
    negative_selected_runs = sum(coefficient < 0),
    zero_or_not_selected_runs = total_outer_runs - selected_runs,
    selection_frequency_all_outer_runs = selected_runs / total_outer_runs,
    selection_frequency_when_screened = selected_runs / screened_runs,
    selection_frequency_when_top20 = if_else(
      top20_input_runs > 0, selected_runs / top20_input_runs, NA_real_
    ),
    positive_sign_frequency_among_selected = if_else(
      selected_runs > 0, positive_selected_runs / selected_runs, NA_real_
    ),
    negative_sign_frequency_among_selected = if_else(
      selected_runs > 0, negative_selected_runs / selected_runs, NA_real_
    ),
    median_nonzero_coefficient = if (any(selected_nonzero)) {
      median(coefficient[selected_nonzero])
    } else NA_real_,
    .groups = "drop"
  ) %>%
  arrange(model, desc(selection_frequency_all_outer_runs), gene_name)
write.table(
  all_gene_stability,
  "tables/model/redesign/all_gene_selection_and_sign_stability.tsv",
  sep = "\t", quote = FALSE, row.names = FALSE, na = "NA"
)

# Reassemble dense survival predictions in patient order for each repeat.
model_map <- c(Clinical_only = "clinical", Gene_only = "gene", Combined = "combined")
metric_rows <- list(); mk <- 1L
for (repeat_id in seq_len(repeats)) {
  z <- oof[oof$repetition == repeat_id, ]
  for (model_name in names(model_map)) {
    score_column <- c(Clinical_only = "clinical_lp", Gene_only = "gene_lp",
                      Combined = "combined_lp")[[model_name]]
    score <- z[[score_column]]
    fold_objects <- dense_rows[vapply(dense_rows, function(x) x$repetition == repeat_id, logical(1))]
    dense <- matrix(NA_real_, nrow = nrow(z), ncol = length(ibs_grid))
    for (object in fold_objects) {
      idx <- match(object$patient_id, z$patient_id)
      dense[idx, ] <- object[[model_map[[model_name]]]]
    }
    brier <- vapply(seq_along(ibs_grid), function(j) {
      ipcw_brier_redesign(z$OS_time, z$OS_event, dense[, j], ibs_grid[j])
    }, numeric(1))
    auc <- tryCatch(suppressWarnings(timeROC(
      T = z$OS_time, delta = z$OS_event, marker = score,
      cause = 1, weighting = "marginal", times = horizons, iid = FALSE
    )$AUC), error = function(e) rep(NA_real_, 3))
    slope <- tryCatch(unname(coef(coxph(Surv(z$OS_time, z$OS_event) ~ score))[1]),
                      error = function(e) NA_real_)
    horizon_index <- match(horizons, ibs_grid)
    metric_rows[[mk]] <- data.frame(
      repetition = repeat_id, model = model_name,
      cindex = cindex_redesign(z$OS_time, z$OS_event, score),
      AUC_1y = auc[1], AUC_3y = auc[2], AUC_5y = auc[3],
      Brier_1y = brier[horizon_index[1]],
      Brier_3y = brier[horizon_index[2]],
      Brier_5y = brier[horizon_index[3]],
      IBS = sum(diff(ibs_grid) * (head(brier, -1) + tail(brier, -1)) / 2) /
        (max(ibs_grid) - min(ibs_grid)),
      calibration_slope = slope, stringsAsFactors = FALSE
    )
    mk <- mk + 1L
  }
}
metrics_long <- bind_rows(metric_rows)
metrics_wide <- metrics_long %>%
  pivot_wider(names_from = model, values_from = -c(repetition, model)) %>%
  mutate(
    clinical_cindex = cindex_Clinical_only,
    combined_cindex = cindex_Combined,
    delta_cindex = combined_cindex - clinical_cindex,
    clinical_ibs = IBS_Clinical_only,
    combined_ibs = IBS_Combined,
    delta_ibs = combined_ibs - clinical_ibs,
    delta_AUC_1y = AUC_1y_Combined - AUC_1y_Clinical_only,
    delta_AUC_3y = AUC_3y_Combined - AUC_3y_Clinical_only,
    delta_AUC_5y = AUC_5y_Combined - AUC_5y_Clinical_only,
    delta_Brier_1y = Brier_1y_Combined - Brier_1y_Clinical_only,
    delta_Brier_3y = Brier_3y_Combined - Brier_3y_Clinical_only,
    delta_Brier_5y = Brier_5y_Combined - Brier_5y_Clinical_only
  )
write.table(
  metrics_wide, "tables/model/nested_incremental_value_by_repeat.tsv",
  sep = "\t", quote = FALSE, row.names = FALSE
)
write.table(
  metrics_long, "tables/model/redesign/nested_model_metrics_long.tsv",
  sep = "\t", quote = FALSE, row.names = FALSE
)

cat("Incremental redesign nested CV completed.\n")
print(metrics_wide %>% select(
  repetition, clinical_cindex, combined_cindex, delta_cindex,
  clinical_ibs, combined_ibs, delta_ibs
))
