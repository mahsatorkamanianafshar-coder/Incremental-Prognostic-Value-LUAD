# Shared deterministic rules used by full-training and outer-fold analyses.

select_one_sample_per_patient_type <- function(sample_info) {
  sample_info <- as.data.frame(sample_info)
  if (!"sample_barcode" %in% names(sample_info)) {
    sample_info$sample_barcode <- rownames(sample_info)
  }
  if (!"patient_id" %in% names(sample_info)) {
    sample_info$patient_id <- substr(sample_info$sample_barcode, 1, 12)
  }
  sample_info %>%
    filter(sample_type %in% c("Primary Tumor", "Solid Tissue Normal")) %>%
    arrange(patient_id, sample_type, sample_barcode) %>%
    group_by(patient_id, sample_type) %>%
    slice_head(n = 1L) %>%
    ungroup()
}

select_paired_tumor_normal_samples <- function(sample_info) {
  selected <- select_one_sample_per_patient_type(sample_info)
  paired_ids <- selected %>%
    distinct(patient_id, sample_type) %>%
    count(patient_id, name = "n_types") %>%
    filter(n_types == 2L) %>%
    pull(patient_id)
  selected %>%
    filter(patient_id %in% paired_ids) %>%
    arrange(patient_id, sample_type, sample_barcode)
}

protein_coding_mask <- function(annotation) {
  annotation <- as.data.frame(annotation)
  gene_type <- if ("gene_type" %in% names(annotation)) {
    as.character(annotation$gene_type)
  } else {
    rep(NA_character_, nrow(annotation))
  }
  gene_biotype <- if ("gene_biotype" %in% names(annotation)) {
    as.character(annotation$gene_biotype)
  } else {
    rep(NA_character_, nrow(annotation))
  }
  coding_label <- ifelse(
    !is.na(gene_type) & trimws(gene_type) != "",
    gene_type,
    gene_biotype
  )
  if (all(is.na(coding_label) | trimws(coding_label) == "")) {
    stop("Protein-coding annotation is unavailable; refusing inconsistent filtering.")
  }
  tolower(trimws(coding_label)) == "protein_coding"
}
