# Full outcome-dependent feature discovery for one outer-analysis fold.
# This file is sourced by scripts/08_LASSO_Cox_prognostic_model.R.
source("scripts/lib_analysis_rules.R")

# Leakage-safe paired-DEG discovery used by both outer- and inner-analysis
# partitions.  This deliberately stops at the strict Top-500: survival and
# clinical-adjusted ranking must be performed later using only the same
# analysis partition.
discover_fold_top500_deg <- function(
  count_matrix, sample_info, gene_info, analysis_patient_ids,
  top_deg_n = 500L, minimum_pairs = 3L
) {
  sample_info <- as.data.frame(sample_info)
  sample_info$sample_barcode <- rownames(sample_info)
  sample_info$patient_id <- substr(sample_info$sample_barcode, 1, 12)
  discovery_info <- sample_info[
    sample_info$sample_type %in% c("Primary Tumor", "Solid Tissue Normal") &
      sample_info$patient_id %in% analysis_patient_ids, , drop = FALSE
  ]
  discovery_info <- select_paired_tumor_normal_samples(discovery_info)
  discovery_info <- as.data.frame(discovery_info)
  rownames(discovery_info) <- discovery_info$sample_barcode
  pair_count <- length(unique(discovery_info$patient_id))
  if (pair_count < minimum_pairs ||
      nrow(discovery_info) != 2L * pair_count) {
    stop("Too few deterministic paired tumor-normal patients in analysis fold.")
  }

  discovery_info$sample_type <- factor(
    ifelse(discovery_info$sample_type == "Primary Tumor", "Tumor", "Normal"),
    levels = c("Normal", "Tumor")
  )
  discovery_info$patient_block <- factor(
    make.names(discovery_info$patient_id, unique = FALSE)
  )
  discovery_counts <- round(
    count_matrix[, discovery_info$sample_barcode, drop = FALSE]
  )
  storage.mode(discovery_counts) <- "integer"
  discovery_counts <- discovery_counts[
    rowSums(discovery_counts >= 10) >= 3, , drop = FALSE
  ]
  dds <- DESeqDataSetFromMatrix(
    countData = discovery_counts, colData = discovery_info,
    design = ~ patient_block + sample_type
  )
  workers <- as.integer(Sys.getenv("REDESIGN_DESEQ_WORKERS", "1"))
  workers <- max(1L, workers)
  bp <- if (workers > 1L) BiocParallel::SnowParam(
    workers = workers, type = "SOCK", progressbar = FALSE
  ) else BiocParallel::SerialParam()
  dds <- DESeq(
    dds, quiet = TRUE, parallel = workers > 1L, BPPARAM = bp
  )
  result_name <- grep("^sample_type_Tumor_vs_Normal$", resultsNames(dds),
                      value = TRUE)
  if (length(result_name) != 1L) {
    stop("Paired DEG sample-type coefficient was not uniquely identified.")
  }
  deg <- as.data.frame(results(dds, name = result_name)) %>%
    rownames_to_column("gene_id")

  # Retry non-converged coefficients with a larger iteration budget, then
  # exclude any remaining failures from inferential filtering.
  failed <- which(!mcols(dds)$betaConv)
  if (length(failed)) {
    dds <- nbinomWaldTest(dds, maxit = 1000, quiet = TRUE)
    deg <- as.data.frame(results(dds, name = result_name)) %>%
      rownames_to_column("gene_id")
    failed <- which(!mcols(dds)$betaConv)
    if (length(failed)) {
      bad <- rownames(dds)[failed]
      inferential <- intersect(
        c("log2FoldChange", "lfcSE", "stat", "pvalue", "padj"), names(deg)
      )
      deg[deg$gene_id %in% bad, inferential] <- NA_real_
    }
  }

  annotation <- as.data.frame(gene_info) %>%
    rownames_to_column("gene_id_original") %>%
    select(any_of(c(
      "gene_id_original", "gene_name", "gene_type", "gene_biotype"
    )))
  deg <- deg %>%
    left_join(annotation, by = c("gene_id" = "gene_id_original"))
  if (!"gene_name" %in% names(deg)) deg$gene_name <- deg$gene_id
  strict <- deg[protein_coding_mask(deg), , drop = FALSE] %>%
    filter(
      is.finite(padj), is.finite(log2FoldChange), is.finite(baseMean),
      padj < 0.01, abs(log2FoldChange) >= 1.5, baseMean >= 50,
      !is.na(gene_name), trimws(gene_name) != ""
    ) %>%
    arrange(padj, desc(abs(log2FoldChange)), gene_id)
  top500 <- strict %>% slice_head(n = top_deg_n)
  if (nrow(top500) < 20L) stop("Fewer than 20 strict paired DEGs in fold.")
  list(
    top500_deg = top500,
    summary = data.frame(
      analysis_patients = length(unique(analysis_patient_ids)),
      paired_patients = pair_count,
      analyzed_genes = nrow(discovery_counts),
      strict_deg_count = nrow(strict),
      top500_count = nrow(top500),
      nonconverged_count = length(failed),
      stringsAsFactors = FALSE
    )
  )
}

discover_outer_fold_genes <- function(
  count_matrix,
  sample_info,
  gene_info,
  analysis_patient_ids,
  clinical_survival,
  top_deg_n = 500L,
  top_gene_n = 100L
) {
  sample_info <- as.data.frame(sample_info)
  sample_info$sample_barcode <- rownames(sample_info)
  sample_info$patient_id <- substr(sample_info$sample_barcode, 1, 12)

  keep_discovery <-
    sample_info$sample_type %in% c("Primary Tumor", "Solid Tissue Normal") &
    sample_info$patient_id %in% analysis_patient_ids
  discovery_info <- sample_info[keep_discovery, , drop = FALSE]
  discovery_info <- select_paired_tumor_normal_samples(discovery_info)
  discovery_info <- as.data.frame(discovery_info)
  rownames(discovery_info) <- discovery_info$sample_barcode
  discovery_counts <- count_matrix[, discovery_info$sample_barcode, drop = FALSE]

  group_counts <- table(discovery_info$sample_type)
  if (!all(c("Primary Tumor", "Solid Tissue Normal") %in% names(group_counts)) ||
      any(group_counts[c("Primary Tumor", "Solid Tissue Normal")] < 3)) {
    stop("Outer fold has too few tumor or normal samples for DEG analysis.")
  }

  discovery_info$sample_type <- factor(
    ifelse(discovery_info$sample_type == "Primary Tumor", "Tumor", "Normal"),
    levels = c("Normal", "Tumor")
  )
  discovery_info$patient_block <- factor(
    make.names(discovery_info$patient_id, unique = FALSE)
  )
  discovery_counts <- round(discovery_counts)
  storage.mode(discovery_counts) <- "integer"
  keep_genes <- rowSums(discovery_counts >= 10) >= 3
  discovery_counts <- discovery_counts[keep_genes, , drop = FALSE]

  dds_deg <- DESeqDataSetFromMatrix(
    countData = discovery_counts,
    colData = discovery_info,
    design = ~ patient_block + sample_type
  )
  dds_deg <- DESeq(dds_deg, quiet = TRUE)
  deg <- as.data.frame(results(
    dds_deg,
    contrast = c("sample_type", "Tumor", "Normal")
  )) %>%
    rownames_to_column("gene_id")

  annotation <- as.data.frame(gene_info) %>%
    rownames_to_column("gene_id_original") %>%
    select(any_of(c("gene_id_original", "gene_name", "gene_type", "gene_biotype")))
  deg <- deg %>% left_join(annotation, by = c("gene_id" = "gene_id_original"))
  if (!"gene_name" %in% names(deg)) deg$gene_name <- deg$gene_id

  deg <- deg[protein_coding_mask(deg), , drop = FALSE]
  deg_strict <- deg %>%
    filter(
      is.finite(padj), is.finite(log2FoldChange), is.finite(baseMean),
      padj < 0.01, abs(log2FoldChange) >= 1.5, baseMean >= 50
    ) %>%
    arrange(padj, desc(abs(log2FoldChange)))
  deg_top <- deg_strict %>% slice_head(n = top_deg_n)
  if (nrow(deg_top) < 2) stop("Too few strict DEGs in outer fold.")

  tumor_info <- select_one_sample_per_patient_type(sample_info) %>%
    filter(sample_type == "Primary Tumor", patient_id %in% analysis_patient_ids) %>%
    arrange(patient_id, sample_barcode)
  clinical <- clinical_survival %>%
    mutate(
      patient_id = submitter_id,
      OS_time = as.numeric(OS_time),
      OS_event = as.numeric(OS_event)
    ) %>%
    filter(
      patient_id %in% analysis_patient_ids,
      is.finite(OS_time), OS_time > 0,
      OS_event %in% c(0, 1)
    ) %>%
    distinct(patient_id, .keep_all = TRUE)
  common <- intersect(tumor_info$patient_id, clinical$patient_id)
  tumor_info <- tumor_info %>% filter(patient_id %in% common)
  clinical <- clinical[match(tumor_info$patient_id, clinical$patient_id), , drop = FALSE]
  stopifnot(identical(tumor_info$patient_id, clinical$patient_id))

  tumor_counts <- round(count_matrix[, tumor_info$sample_barcode, drop = FALSE])
  storage.mode(tumor_counts) <- "integer"
  tumor_counts <- tumor_counts[rowSums(tumor_counts >= 10) >= 3, , drop = FALSE]
  dds_vst <- DESeqDataSetFromMatrix(
    countData = tumor_counts,
    colData = data.frame(
      row.names = colnames(tumor_counts),
      unit = rep(1, ncol(tumor_counts))
    ),
    design = ~ 1
  )
  dds_vst <- estimateSizeFactors(dds_vst)
  vst_matrix <- assay(vst(dds_vst, blind = TRUE))
  candidate_ids <- intersect(deg_top$gene_id, rownames(vst_matrix))

  cox_rows <- lapply(candidate_ids, function(gene_id) {
    value <- as.numeric(scale(vst_matrix[gene_id, ]))
    fit <- tryCatch(
      coxph(Surv(clinical$OS_time, clinical$OS_event) ~ value),
      error = function(e) NULL
    )
    if (is.null(fit)) {
      return(data.frame(gene_id = gene_id, HR = NA_real_, lower95 = NA_real_,
                        upper95 = NA_real_, cox_pvalue = NA_real_))
    }
    s <- summary(fit)
    data.frame(
      gene_id = gene_id,
      HR = s$coefficients[1, "exp(coef)"],
      lower95 = s$conf.int[1, "lower .95"],
      upper95 = s$conf.int[1, "upper .95"],
      cox_pvalue = s$coefficients[1, "Pr(>|z|)"]
    )
  })
  cox_table <- bind_rows(cox_rows) %>%
    mutate(cox_FDR = p.adjust(cox_pvalue, method = "BH"))

  survival_deg <- deg_top %>%
    inner_join(cox_table, by = "gene_id") %>%
    filter(is.finite(cox_pvalue), cox_pvalue < 0.05) %>%
    mutate(
      survival_effect = if_else(HR > 1, "Risk_gene", "Protective_gene"),
      regulation = if_else(log2FoldChange > 0, "Upregulated", "Downregulated"),
      priority_score = abs(log2FoldChange) * -log10(pmax(cox_pvalue, .Machine$double.xmin))
    ) %>%
    filter(!is.na(gene_name), gene_name != "") %>%
    arrange(desc(priority_score)) %>%
    distinct(gene_name, .keep_all = TRUE)
  if (nrow(survival_deg) < 2) stop("Too few survival-related DEGs in outer fold.")

  selected <- survival_deg %>% slice_head(n = top_gene_n)
  list(
    selected = selected,
    # Retain the complete strict Top-500 table so redesigned pipelines can
    # perform separate univariate and clinical-adjusted survival screens
    # without reusing the assessment fold or being restricted to the legacy
    # univariate Top-100 ranking.
    top500_deg = deg_top,
    univariate_survival_screen = deg_top %>%
      inner_join(cox_table, by = "gene_id") %>%
      arrange(cox_pvalue),
    summary = data.frame(
      analysis_patients = length(unique(analysis_patient_ids)),
      tumor_samples = unname(group_counts[["Primary Tumor"]]),
      normal_samples = unname(group_counts[["Solid Tissue Normal"]]),
      analyzed_genes = nrow(discovery_counts),
      strict_deg_count = nrow(deg_strict),
      survival_tested_count = length(candidate_ids),
      survival_p05_count = nrow(survival_deg),
      selected_top_count = nrow(selected)
    )
  )
}
