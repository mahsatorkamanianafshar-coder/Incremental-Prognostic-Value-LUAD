# Offline GEO loader using already archived series-matrix and platform files.
read_geo_platform_table <- function(path) {
  con <- if (grepl("[.]gz$", path, ignore.case = TRUE)) gzfile(path, "rt") else file(path, "rt")
  on.exit(close(con), add = TRUE)
  lines <- readLines(con, warn = FALSE)
  begin_marker <- grep("^!platform_table_begin", lines, ignore.case = TRUE)
  if (length(begin_marker) > 0L) {
    start <- begin_marker[1] + 1L
    end_marker <- grep("^!platform_table_end", lines, ignore.case = TRUE)
    end <- if (length(end_marker) > 0L) end_marker[1] - 1L else length(lines)
  } else {
    start <- grep("^ID\\t", lines)[1]
    end <- length(lines)
  }
  if (!is.finite(start) || start >= end) stop("Could not locate GEO platform table in ", path)
  read.delim(
    text = paste(lines[start:end], collapse = "\n"),
    stringsAsFactors = FALSE, check.names = FALSE, quote = ""
  )
}

load_local_geo_eset <- function(series_matrix_file, platform_file) {
  if (!file.exists(series_matrix_file) || !file.exists(platform_file)) {
    stop("Local GEO series-matrix or platform annotation is missing.")
  }
  eset <- GEOquery::getGEO(filename = series_matrix_file, getGPL = FALSE)
  platform <- read_geo_platform_table(platform_file)
  id_col <- names(platform)[tolower(names(platform)) == "id"][1]
  if (is.na(id_col)) stop("Platform annotation has no ID column: ", platform_file)
  feature_ids <- rownames(Biobase::exprs(eset))
  matched <- platform[match(feature_ids, as.character(platform[[id_col]])), , drop = FALSE]
  rownames(matched) <- feature_ids
  Biobase::featureData(eset) <- Biobase::AnnotatedDataFrame(matched)
  eset
}
