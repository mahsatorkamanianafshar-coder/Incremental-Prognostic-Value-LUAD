# ============================================================
# External incremental validation of the frozen redesign model
# ============================================================

suppressPackageStartupMessages({
  library(GEOquery)
  library(Biobase)
  library(tidyverse)
  library(survival)
  library(glmnet)
  library(timeROC)
})
source("scripts/lib_local_geo_loader.R")
source("scripts/lib_incremental_redesign.R")

output_tag <- trimws(Sys.getenv("REDESIGN_EXTERNAL_OUTPUT_TAG", ""))
external_table_dir <- if (nzchar(output_tag)) {
  file.path("tables/external_validation", output_tag)
} else "tables/external_validation"
external_result_dir <- if (nzchar(output_tag)) {
  file.path("results/external_validation/redesign", output_tag)
} else "results/external_validation/redesign"
dir.create(external_table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(external_result_dir, recursive = TRUE, showWarnings = FALSE)

frozen_path <- Sys.getenv(
  "REDESIGN_FROZEN_PATH",
  "results/model/redesign/frozen_incremental_joint_model.rds"
)
frozen <- readRDS(frozen_path)
stopifnot(frozen$version %in% c(
  "incremental_redesign_v2_end_to_end",
  "incremental_redesign_v3_M20_smoking_constrained_primary",
  "incremental_redesign_v3_M20_YuGene_full_pipeline_sensitivity"
))
feature_transform <- if (is.null(frozen$feature_transform)) "s_score" else frozen$feature_transform
stopifnot(feature_transform %in% c("s_score", "yugene"))
required_genes <- unique(c(frozen$candidate_genes, frozen$reference_genes))
horizons <- c(365, 1095, 1825)
time_grid <- sort(unique(c(seq(30, 1825, length.out = 100L), horizons)))
bootstrap_replicates <- as.integer(Sys.getenv("EXTERNAL_INCREMENTAL_BOOTSTRAP", "1000"))

extract_symbol <- function(x, preferred) {
  x <- trimws(as.character(x))
  x[x %in% c("", "---", "NA", "na", "null")] <- NA_character_
  vapply(strsplit(x, "\\s*///\\s*|\\s*//\\s*|;|,|\\|", perl = TRUE),
         function(v) {
           v <- toupper(trimws(v)); v <- v[nzchar(v) & !is.na(v)]
           if (!length(v)) return(NA_character_)
           hit <- v[v %in% preferred]
           if (length(hit)) hit[1] else v[1]
         }, character(1))
}

# Predeclared current-symbol aliases; applied without using cohort outcomes.
external_aliases <- c(SGO1 = "SGOL1")
apply_external_aliases <- function(gene_matrix, preferred) {
  applied <- character(0)
  for (current in intersect(names(external_aliases), preferred)) {
    legacy <- unname(external_aliases[[current]])
    if (!current %in% rownames(gene_matrix) && legacy %in% rownames(gene_matrix)) {
      rownames(gene_matrix)[rownames(gene_matrix) == legacy] <- current
      applied <- c(applied, paste0(legacy, "->", current))
    }
  }
  attr(gene_matrix, "external_aliases_applied") <- applied
  gene_matrix
}

load_gene_expression <- function(series_file, platform_file, preferred) {
  cache_path <- file.path(
    "results/external_validation/redesign",
    paste0(sub("_series_matrix[.]txt[.]gz$", "", basename(series_file)),
           "_gene_level_expression_cache.rds")
  )
  if (file.exists(cache_path)) {
    cached <- readRDS(cache_path)
    if (!is.null(cached$result$matrix)) {
      cached$result$matrix <- apply_external_aliases(cached$result$matrix, preferred)
      if (all(preferred %in% rownames(cached$result$matrix))) return(cached$result)
    }
  }
  eset <- load_local_geo_eset(series_file, platform_file)
  expr <- exprs(eset); annotation <- fData(eset)
  candidates <- names(annotation)[vapply(annotation, function(x)
    is.character(x) || is.factor(x), logical(1))]
  if (!length(candidates)) stop("No text annotation columns in platform file.")
  scored <- lapply(candidates, function(nm) {
    symbol <- extract_symbol(annotation[[nm]], preferred)
    data.frame(column = nm,
               overlap = sum(preferred %in% unique(symbol)),
               stringsAsFactors = FALSE)
  }) %>% bind_rows() %>% arrange(desc(overlap), column)
  selected_column <- scored$column[1]
  symbols <- extract_symbol(annotation[[selected_column]], preferred)
  expr_df <- as.data.frame(expr, check.names = FALSE)
  expr_df$gene_name <- symbols
  gene_matrix <- expr_df %>% filter(!is.na(gene_name), gene_name != "") %>%
    group_by(gene_name) %>%
    summarise(across(where(is.numeric), ~ mean(.x, na.rm = TRUE)),
              .groups = "drop") %>%
    column_to_rownames("gene_name") %>% as.matrix()
  storage.mode(gene_matrix) <- "numeric"
  gene_matrix <- apply_external_aliases(gene_matrix, preferred)
  missing <- setdiff(preferred, rownames(gene_matrix))
  if (length(missing)) stop("Required genes missing after mapping: ",
                            paste(missing, collapse = ", "))
  result <- list(matrix = gene_matrix, annotation_column = selected_column,
                 overlap = scored$overlap[1])
  saveRDS(list(required_genes = preferred, result = result), cache_path,
          compress = "xz")
  result
}

read_pheno <- function(path) {
  read.delim(path, row.names = 1, check.names = FALSE,
             stringsAsFactors = FALSE)
}

first_column <- function(data, candidates) {
  hit <- candidates[candidates %in% names(data)]
  if (!length(hit)) return(rep(NA_character_, nrow(data)))
  data[[hit[1]]]
}

external_clinical_matrix <- function(pheno, sample_ids, cohort) {
  pheno <- pheno[sample_ids, , drop = FALSE]
  if (cohort == "GSE72094") {
    age <- suppressWarnings(as.numeric(first_column(pheno, c(
      "parsed_age_at_diagnosis", "age_at_diagnosis_ch1"))))
    stage <- stage_numeric_redesign(first_column(pheno, c(
      "parsed_stage", "stage_ch1")))
    sex <- first_column(pheno, c("parsed_gender", "gender_ch1"))
  } else {
    age <- suppressWarnings(as.numeric(first_column(pheno, c(
      "parsed_age_years", "age_years_ch1", "parsed_age", "age_ch1"))))
    stage <- stage_numeric_redesign(first_column(pheno, c(
      "parsed_pathological_stage", "pathological_stage_ch1",
      "parsed_pstage_iorii", "pstage_iorii_ch1")))
    sex <- first_column(pheno, c("parsed_gender", "gender_ch1"))
  }
  sex <- tolower(trimws(as.character(sex)))
  male <- ifelse(sex %in% c("male", "m"), 1,
                 ifelse(sex %in% c("female", "f"), 0, NA_real_))
  age[!is.finite(age)] <- frozen$clinical_imputation$age_median
  stage[!is.finite(stage)] <- frozen$clinical_imputation$stage_mode
  male[!is.finite(male)] <- frozen$clinical_imputation$male_mode
  matrix <- cbind(
    age_per_10y = age / 10,
    stage_II = as.numeric(stage == 2),
    stage_III = as.numeric(stage == 3),
    stage_IV = as.numeric(stage == 4),
    male = male
  )
  matrix <- matrix[, frozen$clinical_columns, drop = FALSE]
  list(matrix = matrix,
       missing_age = sum(!is.finite(suppressWarnings(as.numeric(first_column(
         pheno, if (cohort == "GSE72094") c("parsed_age_at_diagnosis")
         else c("parsed_age_years")))))),
       missing_stage = sum(!is.finite(stage_numeric_redesign(first_column(
         pheno, if (cohort == "GSE72094") c("parsed_stage")
         else c("parsed_pathological_stage"))))),
       missing_sex = sum(!sex %in% c("male", "m", "female", "f")))
}

model_features <- function(gene_matrix, sample_ids) {
  if (feature_transform == "yugene") {
    transformed <- yugene_transform_redesign(
      gene_matrix[, sample_ids, drop = FALSE]
    )
    out <- t(transformed[frozen$candidate_genes, , drop = FALSE])
    rm(transformed)
    return(out)
  }
  refs <- gene_matrix[frozen$reference_genes, sample_ids, drop = FALSE]
  raw <- gene_matrix[frozen$candidate_genes, sample_ids, drop = FALSE]
  relative <- t(vapply(seq_len(nrow(raw)), function(i) {
    (1 + colSums(sweep(refs, 2, raw[i, ], FUN = "<="))) /
      (nrow(refs) + 1)
  }, numeric(ncol(raw))))
  rownames(relative) <- frozen$candidate_genes
  colnames(relative) <- sample_ids
  t(relative)
}

hazard_at <- function(baseline, grid) {
  vapply(grid, function(tt) {
    z <- baseline$hazard[baseline$time <= tt]
    if (length(z)) max(z) else 0
  }, numeric(1))
}

frozen_survival <- function(lp, model) {
  if (model == "clinical") {
    h0 <- hazard_at(frozen$clinical_only_baseline_hazard, time_grid)
    exp(-outer(exp(frozen$clinical_only_calibration_slope * lp), h0))
  } else {
    h0 <- hazard_at(frozen$baseline_hazard, time_grid)
    exp(-outer(exp(frozen$calibration_slope * lp), h0))
  }
}

ipcw_curve_external <- function(time, event, predicted) {
  censor_fit <- survfit(Surv(time, 1 - event) ~ 1)
  g_i <- pmax(step_survival_redesign(censor_fit, time), 1e-6)
  vapply(seq_along(time_grid), function(j) {
    tt <- time_grid[j]
    g_t <- pmax(step_survival_redesign(censor_fit, rep(tt, length(time))), 1e-6)
    weight <- ifelse(time <= tt & event == 1, 1 / g_i,
                     ifelse(time > tt, 1 / g_t, 0))
    mean(weight * (as.numeric(time > tt) - predicted[, j])^2)
  }, numeric(1))
}

evaluate_pair <- function(data, analysis_label) {
  auc_c <- suppressWarnings(timeROC(T = data$OS_time, delta = data$OS_event,
    marker = data$clinical_lp, cause = 1, weighting = "marginal",
    times = horizons, iid = FALSE)$AUC)
  auc_j <- suppressWarnings(timeROC(T = data$OS_time, delta = data$OS_event,
    marker = data$combined_lp, cause = 1, weighting = "marginal",
    times = horizons, iid = FALSE)$AUC)
  bc <- ipcw_curve_external(data$OS_time, data$OS_event,
                            as.matrix(data[, grep("^clinical_S_", names(data))]))
  bj <- ipcw_curve_external(data$OS_time, data$OS_event,
                            as.matrix(data[, grep("^combined_S_", names(data))]))
  hi <- match(horizons, time_grid)
  clinical_refit <- coxph(Surv(OS_time, OS_event) ~ clinical_lp, data = data)
  incremental_refit <- coxph(
    Surv(OS_time, OS_event) ~ clinical_lp + gene_component, data = data
  )
  lrt <- anova(clinical_refit, incremental_refit, test = "LRT")
  clinical_c <- cindex_redesign(data$OS_time, data$OS_event, data$clinical_lp)
  combined_c <- cindex_redesign(data$OS_time, data$OS_event, data$combined_lp)
  clinical_ibs <- sum(diff(time_grid) *
                        (head(bc, -1) + tail(bc, -1)) / 2) /
    diff(range(time_grid))
  combined_ibs <- sum(diff(time_grid) *
                        (head(bj, -1) + tail(bj, -1)) / 2) /
    diff(range(time_grid))
  data.frame(
    cohort = unique(data$cohort), analysis = analysis_label,
    n = nrow(data), events = sum(data$OS_event),
    clinical_cindex = clinical_c,
    combined_cindex = combined_c,
    delta_cindex = combined_c - clinical_c,
    clinical_AUC_1y = auc_c[1], combined_AUC_1y = auc_j[1],
    delta_AUC_1y = auc_j[1] - auc_c[1],
    clinical_AUC_3y = auc_c[2], combined_AUC_3y = auc_j[2],
    delta_AUC_3y = auc_j[2] - auc_c[2],
    clinical_AUC_5y = auc_c[3], combined_AUC_5y = auc_j[3],
    delta_AUC_5y = auc_j[3] - auc_c[3],
    clinical_Brier_1y = bc[hi[1]], combined_Brier_1y = bj[hi[1]],
    delta_Brier_1y = bj[hi[1]] - bc[hi[1]],
    clinical_Brier_3y = bc[hi[2]], combined_Brier_3y = bj[hi[2]],
    delta_Brier_3y = bj[hi[2]] - bc[hi[2]],
    clinical_Brier_5y = bc[hi[3]], combined_Brier_5y = bj[hi[3]],
    delta_Brier_5y = bj[hi[3]] - bc[hi[3]],
    clinical_IBS = clinical_ibs,
    combined_IBS = combined_ibs,
    delta_IBS = combined_ibs - clinical_ibs,
    clinical_calibration_slope = unname(coef(clinical_refit)[1]),
    combined_calibration_slope = tryCatch(unname(coef(coxph(
      Surv(OS_time, OS_event) ~ combined_lp, data = data))[1]),
      error = function(e) NA_real_),
    external_refit_gene_LRT_p = lrt[2, "Pr(>|Chi|)"],
    LRT_interpretation = "secondary_external_refit_diagnostic_not_frozen_performance",
    stringsAsFactors = FALSE
  )
}

cohort_config <- list(
  GSE72094 = list(
    series = "data_raw/GEO/GSE72094_series_matrix.txt.gz",
    platform = "data_raw/GEO/GPL15048.soft.gz",
    pheno = "tables/external_validation/GSE72094_pheno_clean_for_manual_check.tsv",
    survival = "results/external_validation/GSE72094_external_risk_scores.tsv"
  ),
  GSE31210 = list(
    series = "data_raw/GEO/GSE31210_series_matrix.txt.gz",
    platform = "data_raw/GEO/GPL570.annot.gz",
    pheno = "tables/external_validation/GSE31210_pheno_clean.tsv",
    survival = "results/external_validation/GSE31210_external_risk_scores.tsv"
  )
)

prediction_sets <- list(); mapping_audit <- list()
for (cohort in names(cohort_config)) {
  cfg <- cohort_config[[cohort]]
  expression <- load_gene_expression(cfg$series, cfg$platform, required_genes)
  pheno <- read_pheno(cfg$pheno)
  survival_data <- read.delim(cfg$survival) %>%
    select(sample_id, OS_time, OS_event)
  samples <- survival_data$sample_id
  stopifnot(all(samples %in% colnames(expression$matrix)),
            all(samples %in% rownames(pheno)))
  clinical <- external_clinical_matrix(pheno, samples, cohort)
  genes <- model_features(expression$matrix, samples)
  clinical_lp <- as.numeric(clinical$matrix %*% frozen$clinical_only_coefficients)
  joint_matrix <- cbind(clinical$matrix, genes[, frozen$candidate_genes, drop = FALSE])
  combined_lp <- as.numeric(predict(frozen$glmnet_fit, newx = joint_matrix,
                                    type = "link"))
  gene_names <- intersect(names(frozen$coefficients), frozen$candidate_genes)
  gene_component <- as.numeric(genes[, gene_names, drop = FALSE] %*%
                                 frozen$coefficients[gene_names])
  clinical_surv <- frozen_survival(clinical_lp, "clinical")
  combined_surv <- frozen_survival(combined_lp, "combined")
  prediction <- data.frame(
    cohort = cohort, sample_id = samples,
    OS_time = survival_data$OS_time, OS_event = survival_data$OS_event,
    clinical_lp = clinical_lp, gene_component = gene_component,
    combined_lp = combined_lp, stringsAsFactors = FALSE
  )
  prediction[paste0("clinical_S_", seq_along(time_grid))] <- clinical_surv
  prediction[paste0("combined_S_", seq_along(time_grid))] <- combined_surv
  if (cohort == "GSE31210") {
    flag <- tolower(trimws(as.character(first_column(pheno[samples, , drop = FALSE], c(
      "parsed_exclude_for_prognosis_analysis_due_to_incomplete_resection_or_adjuvant_therapy",
      "exclude_for_prognosis_analysis_due_to_incomplete_resection_or_adjuvant_therapy_ch1")))))
    prediction$prognosis_exclusion_flag <- flag == "exclude"
  } else prediction$prognosis_exclusion_flag <- FALSE
  prediction_sets[[cohort]] <- prediction
  mapping_audit[[cohort]] <- data.frame(
    cohort = cohort, annotation_column = expression$annotation_column,
    feature_transform = feature_transform,
    frozen_model_path = normalizePath(frozen_path, winslash = "/"),
    required_gene_overlap = expression$overlap,
    required_gene_count = length(required_genes), n = nrow(prediction),
    aliases_applied = paste(
      attr(expression$matrix, "external_aliases_applied"), collapse = ";"
    ),
    events = sum(prediction$OS_event), missing_age = clinical$missing_age,
    missing_stage = clinical$missing_stage, missing_sex = clinical$missing_sex,
    stringsAsFactors = FALSE
  )
  write.table(prediction %>% select(-matches("_S_[0-9]+$")),
              file.path(external_result_dir,
                        paste0(cohort, "_incremental_predictions.tsv")),
              sep = "\t", quote = FALSE, row.names = FALSE)
}

analyses <- list(
  GSE72094_primary = prediction_sets$GSE72094,
  GSE31210_primary_exploratory = prediction_sets$GSE31210,
  GSE31210_excluding_22_flagged = prediction_sets$GSE31210 %>%
    filter(!prognosis_exclusion_flag)
)
stopifnot(nrow(analyses$GSE72094_primary) == 398L,
          sum(analyses$GSE72094_primary$OS_event) == 113L,
          nrow(analyses$GSE31210_primary_exploratory) == 226L,
          sum(analyses$GSE31210_primary_exploratory$OS_event) == 35L,
          sum(prediction_sets$GSE31210$prognosis_exclusion_flag) == 22L)

metric_rows <- Map(evaluate_pair, analyses, names(analyses)) %>% bind_rows()
write.table(metric_rows,
            file.path(external_table_dir, "external_incremental_validation.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(bind_rows(mapping_audit),
            file.path(external_table_dir, "external_incremental_mapping_audit.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

# Paired patient bootstrap for external incremental differences.
set.seed(94001L)
bootstrap_rows <- list(); k <- 1L
for (analysis_name in names(analyses)) {
  data <- analyses[[analysis_name]]
  for (b in seq_len(bootstrap_replicates)) {
    idx <- sample(seq_len(nrow(data)), replace = TRUE)
    z <- data[idx, ]
    cc <- cindex_redesign(z$OS_time, z$OS_event, z$clinical_lp)
    cj <- cindex_redesign(z$OS_time, z$OS_event, z$combined_lp)
    ac <- tryCatch(suppressWarnings(timeROC(
      T = z$OS_time, delta = z$OS_event, marker = z$clinical_lp,
      cause = 1, weighting = "marginal", times = horizons, iid = FALSE)$AUC),
      error = function(e) rep(NA_real_, 3))
    aj <- tryCatch(suppressWarnings(timeROC(
      T = z$OS_time, delta = z$OS_event, marker = z$combined_lp,
      cause = 1, weighting = "marginal", times = horizons, iid = FALSE)$AUC),
      error = function(e) rep(NA_real_, 3))
    sc <- as.matrix(z[, grep("^clinical_S_", names(z))])
    sj <- as.matrix(z[, grep("^combined_S_", names(z))])
    bc <- ipcw_curve_external(z$OS_time, z$OS_event, sc)
    bj <- ipcw_curve_external(z$OS_time, z$OS_event, sj)
    hi <- match(horizons, time_grid)
    ibsc <- sum(diff(time_grid) * (head(bc, -1) + tail(bc, -1)) / 2) /
      diff(range(time_grid))
    ibsj <- sum(diff(time_grid) * (head(bj, -1) + tail(bj, -1)) / 2) /
      diff(range(time_grid))
    bootstrap_rows[[k]] <- bind_rows(
      data.frame(analysis = analysis_name, replicate = b, metric = "C_index",
                 horizon_days = NA_integer_, clinical = cc, combined = cj,
                 delta = cj - cc),
      data.frame(analysis = analysis_name, replicate = b, metric = "AUC",
                 horizon_days = horizons, clinical = ac, combined = aj,
                 delta = aj - ac),
      data.frame(analysis = analysis_name, replicate = b, metric = "Brier",
                 horizon_days = horizons, clinical = bc[hi], combined = bj[hi],
                 delta = bj[hi] - bc[hi]),
      data.frame(analysis = analysis_name, replicate = b, metric = "IBS",
                 horizon_days = NA_integer_, clinical = ibsc, combined = ibsj,
                 delta = ibsj - ibsc)
    )
    k <- k + 1L
  }
}
bootstrap_table <- bind_rows(bootstrap_rows)
write.table(bootstrap_table,
            file.path(external_table_dir, "external_incremental_bootstrap_replicates.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
bootstrap_summary <- bootstrap_table %>%
  group_by(analysis, metric, horizon_days) %>% summarise(
    estimate = mean(delta, na.rm = TRUE),
    lower95 = quantile(delta, .025, na.rm = TRUE),
    upper95 = quantile(delta, .975, na.rm = TRUE), .groups = "drop"
  )
write.table(bootstrap_summary,
            file.path(external_table_dir, "external_incremental_bootstrap_summary.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

cat("External incremental validation completed.\n")
print(metric_rows %>% select(cohort, analysis, n, events,
                             clinical_cindex, combined_cindex, delta_cindex,
                             clinical_IBS, combined_IBS, delta_IBS,
                             external_refit_gene_LRT_p))
print(bootstrap_summary %>% filter(metric %in% c("C_index", "IBS")))
