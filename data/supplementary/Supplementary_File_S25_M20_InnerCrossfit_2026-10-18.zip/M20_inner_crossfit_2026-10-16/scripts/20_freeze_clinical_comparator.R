# Add the development-only clinical comparator to the redesign artifact.
suppressPackageStartupMessages({
  library(survival)
  library(glmnet)
})
source("scripts/lib_incremental_redesign.R")

model_path <- "results/model/redesign/frozen_incremental_joint_model.rds"
frozen <- readRDS(model_path)
development_source <- read.delim(
  "results/model/risk_scores_training.tsv", check.names = FALSE
)
development <- prepare_raw_clinical_redesign(development_source)
design <- clinical_design_redesign(
  development, development, frozen$clinical_specification, 92001L
)
clinical_model <- cox_matrix_predict_redesign(
  design$train, development$OS_time, development$OS_event, design$test
)
fit <- clinical_model$fit
stopifnot(identical(names(coef(fit)), frozen$clinical_columns))
calibration_fit <- coxph(
  Surv(development$OS_time, development$OS_event) ~ clinical_model$train_lp,
  ties = "breslow"
)
frozen$clinical_only_coefficients <- coef(fit)
frozen$clinical_only_fit <- fit
frozen$clinical_only_calibration_slope <- unname(coef(calibration_fit)[1])
frozen$clinical_only_baseline_hazard <-
  basehaz(calibration_fit, centered = FALSE)
saveRDS(frozen, model_path, compress = "xz")
cat("Frozen clinical-only comparator added to", model_path, "\n")
