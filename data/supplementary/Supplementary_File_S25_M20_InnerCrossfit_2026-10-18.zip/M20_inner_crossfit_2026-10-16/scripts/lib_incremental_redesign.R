# Shared functions for the incremental-value model redesign.

make_stratified_folds_redesign <- function(event, k, seed) {
  set.seed(seed)
  fold <- integer(length(event))
  for (value in sort(unique(event))) {
    idx <- sample(which(event == value), replace = FALSE)
    fold[idx] <- rep(seq_len(k), length.out = length(idx))
  }
  fold
}

# Exact algorithm of the archived CRAN YuGene 1.1.6 implementation
# (R/YuGene.R), adapted only to remove the progress bar and retain an ordinary
# numeric matrix class. Negative inputs are set to zero as in the reference.
# The transform is sample-wise and does not use outcomes or cohort labels.
yugene_transform_redesign <- function(data) {
  data <- as.matrix(data)
  storage.mode(data) <- "numeric"
  if (any(data < 0, na.rm = TRUE)) data[data < 0] <- 0
  out <- matrix(NA_real_, nrow(data), ncol(data),
                dimnames = dimnames(data))
  for (j in seq_len(ncol(data))) {
    sample <- data[, j]
    sample[!is.finite(sample)] <- 0
    duplicated_value <- duplicated(sample)
    ord <- order(sample, decreasing = TRUE)
    unique_in_order <- !duplicated_value[ord]
    by_order <- cbind(index = seq_along(sample), value = sample,
                      cumulative = 2)[ord, , drop = FALSE]
    total <- sum(sample)
    if (!is.finite(total) || total <= 0) {
      out[, j] <- 0
      next
    }
    cumulative <- cumsum(by_order[, "value"]) / total
    by_order[unique_in_order, "cumulative"] <- cumulative[unique_in_order]
    duplicate_positions <- which(!unique_in_order)
    if (length(duplicate_positions)) {
      for (i in duplicate_positions) {
        by_order[i, "cumulative"] <- if (i > 1L) {
          by_order[i - 1L, "cumulative"]
        } else cumulative[i]
      }
    }
    by_index <- by_order[order(by_order[, "index"]), , drop = FALSE]
    out[, j] <- 1 - by_index[, "cumulative"]
  }
  out
}

# Outcome-independent duplicate-symbol aggregation used by the YuGene and
# cohort-wise gene-z benchmarks. The predeclared rule is the arithmetic mean
# across all rows/probes mapped to a symbol.
aggregate_symbol_matrix_redesign <- function(x, symbols) {
  x <- as.matrix(x)
  symbols <- toupper(trimws(as.character(symbols)))
  keep <- is.finite(rowSums(x)) & !is.na(symbols) & nzchar(symbols) &
    !symbols %in% c("NA", "---", "NULL")
  x <- x[keep, , drop = FALSE]
  symbols <- symbols[keep]
  sums <- rowsum(x, group = symbols, reorder = TRUE, na.rm = TRUE)
  counts <- as.numeric(table(factor(symbols, levels = rownames(sums))))
  sweep(sums, 1, counts, "/")
}

stage_numeric_redesign <- function(x) {
  x <- toupper(trimws(as.character(x)))
  x <- gsub("^STAGE\\s*", "", x)
  out <- rep(NA_real_, length(x))
  # External cohorts may encode substages with Arabic numerals (for example
  # 1A, 2B, 3A), whereas TCGA commonly uses Roman numerals. Support both
  # without treating arbitrary digits later in a string as stage labels.
  out[grepl("^1([A-D]|$)", x)] <- 1
  out[grepl("^2([A-D]|$)", x)] <- 2
  out[grepl("^3([A-D]|$)", x)] <- 3
  out[grepl("^4([A-D]|$)", x)] <- 4
  out[grepl("^I", x)] <- 1
  out[grepl("^II", x)] <- 2
  out[grepl("^III", x)] <- 3
  out[grepl("^IV", x)] <- 4
  out
}

ever_smoking_redesign <- function(x) {
  x <- tolower(trimws(as.character(x)))
  out <- rep(NA_real_, length(x))
  out[grepl("lifelong non|never", x)] <- 0
  out[grepl("current smoker|reformed smoker|former|ever", x)] <- 1
  out
}

mode_numeric_redesign <- function(x, fallback = 0) {
  x <- x[is.finite(x)]
  if (!length(x)) return(fallback)
  as.numeric(names(sort(table(x), decreasing = TRUE)[1]))
}

prepare_raw_clinical_redesign <- function(z) {
  age_index <- suppressWarnings(as.numeric(z$age_at_index))
  age_diagnosis <- suppressWarnings(as.numeric(z$age_at_diagnosis)) / 365.25
  age <- ifelse(is.finite(age_index), age_index, age_diagnosis)
  stage <- stage_numeric_redesign(z$ajcc_pathologic_stage)
  sex_text <- if ("sex_at_birth" %in% names(z)) z$sex_at_birth else z$gender
  male <- ifelse(tolower(trimws(as.character(sex_text))) == "male", 1,
                 ifelse(tolower(trimws(as.character(sex_text))) == "female", 0, NA))
  data.frame(
    patient_id = z$patient_id,
    OS_time = as.numeric(z$OS_time),
    OS_event = as.numeric(z$OS_event),
    age = age,
    stage = stage,
    male = male,
    pack_years = suppressWarnings(as.numeric(z$pack_years_smoked)),
    ever_smoking = ever_smoking_redesign(z$tobacco_smoking_status),
    raw_smoking_status = as.character(z$tobacco_smoking_status),
    stringsAsFactors = FALSE
  )
}

basic_impute_redesign <- function(train, test) {
  age_value <- median(train$age, na.rm = TRUE)
  stage_value <- mode_numeric_redesign(train$stage, 1)
  male_value <- mode_numeric_redesign(train$male, 0)
  ever_smoking_value <- mode_numeric_redesign(train$ever_smoking, 1)
  for (nm in c("age", "stage", "male", "ever_smoking")) {
    value <- get(paste0(nm, "_value"))
    train[[nm]][!is.finite(train[[nm]])] <- value
    test[[nm]][!is.finite(test[[nm]])] <- value
  }
  list(train = train, test = test)
}

pmm_pack_years_redesign <- function(train, test, seed, donors = 5L) {
  pmm_rule <- Sys.getenv("REDESIGN_PACK_PMM_RULE", "legacy_unconstrained")
  if (!pmm_rule %in% c("legacy_unconstrained", "smoking_constrained")) {
    stop("Unknown REDESIGN_PACK_PMM_RULE: ", pmm_rule)
  }
  raw_train_ever <- train$ever_smoking
  raw_test_ever <- test$ever_smoking
  train$smoking_unknown <- as.numeric(!is.finite(raw_train_ever))
  test$smoking_unknown <- as.numeric(!is.finite(raw_test_ever))
  prepared <- basic_impute_redesign(train, test)
  train <- prepared$train; test <- prepared$test
  observed_all <- which(is.finite(train$pack_years) & train$pack_years >= 0)
  observed <- if (pmm_rule == "smoking_constrained") {
    which(raw_train_ever == 1 & is.finite(train$pack_years) & train$pack_years >= 0)
  } else observed_all
  if (length(observed) < 20L) stop("Too few observed pack-year donors.")
  predictor_frame <- function(z) data.frame(
    age = z$age, stage = z$stage,
    male = z$male
  )
  fit <- lm(log1p(train$pack_years[observed]) ~ ., data = predictor_frame(train[observed, ]))
  pred_observed <- as.numeric(predict(fit, newdata = predictor_frame(train[observed, ])))
  impute_one <- function(target, prediction, offset, raw_ever) {
    missing <- which(!is.finite(target$pack_years) | target$pack_years < 0)
    if (!length(missing)) return(target)
    if (pmm_rule == "smoking_constrained") {
      # Preserve every observed value. Missing pack-years in known never-smokers
      # are prospectively locked to the structural zero requested for issues
      # 47/48; missing known ever-smokers draw only from known-ever donors.
      never_missing <- missing[is.finite(raw_ever[missing]) & raw_ever[missing] == 0]
      if (length(never_missing)) target$pack_years[never_missing] <- 0
      missing <- setdiff(missing, never_missing)
    }
    set.seed(seed + offset)
    for (i in missing) {
      donor_index <- observed
      donor_prediction <- pred_observed
      # Unknown smoking status is retained as an explicit indicator and never
      # recoded as ever/never. Its separate sensitivity branch uses all
      # observed training donors because no valid within-stratum donor pool
      # exists; this rule is recorded in the sensitivity audit.
      if (pmm_rule == "smoking_constrained" && !is.finite(raw_ever[i])) {
        donor_index <- observed_all
        donor_prediction <- as.numeric(predict(
          fit, newdata = predictor_frame(train[observed_all, ])
        ))
      }
      distance <- abs(donor_prediction - prediction[i])
      nearest <- donor_index[order(distance)[seq_len(min(donors, length(donor_index)))]]
      target$pack_years[i] <- sample(train$pack_years[nearest], 1L)
    }
    target
  }
  train_prediction <- as.numeric(predict(fit, newdata = predictor_frame(train)))
  test_prediction <- as.numeric(predict(fit, newdata = predictor_frame(test)))
  list(
    train = impute_one(train, train_prediction, 1L, raw_train_ever),
    test = impute_one(test, test_prediction, 2L, raw_test_ever)
  )
}

clinical_design_redesign <- function(train, test, specification, seed) {
  constrained <- identical(
    Sys.getenv("REDESIGN_PACK_PMM_RULE", "legacy_unconstrained"),
    "smoking_constrained"
  )
  if (constrained) {
    train$smoking_unknown <- as.numeric(!is.finite(train$ever_smoking))
    test$smoking_unknown <- as.numeric(!is.finite(test$ever_smoking))
  }
  if (grepl("pack", specification)) {
    prepared <- pmm_pack_years_redesign(train, test, seed)
  } else {
    prepared <- basic_impute_redesign(train, test)
  }
  train <- prepared$train; test <- prepared$test
  stage_matrix <- function(x) cbind(
    stage_II = as.numeric(x == 2), stage_III = as.numeric(x == 3),
    stage_IV = as.numeric(x == 4)
  )
  train_stage <- stage_matrix(train$stage); test_stage <- stage_matrix(test$stage)
  nonlinear_age <- grepl("nonlinear", specification)
  if (nonlinear_age) {
    age_basis <- splines::ns(train$age, df = 3)
    age_train <- as.matrix(age_basis)
    age_test <- as.matrix(predict(age_basis, test$age))
    colnames(age_train) <- colnames(age_test) <- paste0("age_ns", 1:3)
  } else {
    age_train <- cbind(age_per_10y = train$age / 10)
    age_test <- cbind(age_per_10y = test$age / 10)
  }
  smoke_train <- matrix(numeric(0), nrow = nrow(train), ncol = 0)
  smoke_test <- matrix(numeric(0), nrow = nrow(test), ncol = 0)
  if (specification %in% c("pack_linear", "pack_nonlinear")) {
    lp_train <- log1p(train$pack_years); lp_test <- log1p(test$pack_years)
    if (specification == "pack_nonlinear") {
      pack_basis <- splines::ns(lp_train, df = 3)
      smoke_train <- as.matrix(pack_basis)
      smoke_test <- as.matrix(predict(pack_basis, lp_test))
      colnames(smoke_train) <- colnames(smoke_test) <- paste0("pack_ns", 1:3)
    } else {
      smoke_train <- cbind(log1p_pack_years = lp_train)
      smoke_test <- cbind(log1p_pack_years = lp_test)
    }
  } else if (specification == "ever_linear") {
    smoke_train <- cbind(ever_smoking = train$ever_smoking)
    smoke_test <- cbind(ever_smoking = test$ever_smoking)
  }
  if (constrained && specification %in% c(
    "pack_linear", "pack_nonlinear", "ever_linear"
  )) {
    smoke_train <- cbind(smoke_train, smoking_unknown = train$smoking_unknown)
    smoke_test <- cbind(smoke_test, smoking_unknown = test$smoking_unknown)
  }
  x_train <- cbind(age_train, train_stage, male = train$male, smoke_train)
  x_test <- cbind(age_test, test_stage, male = test$male, smoke_test)
  keep <- apply(x_train, 2, function(x) is.finite(sd(x)) && sd(x) > 0)
  list(train = x_train[, keep, drop = FALSE], test = x_test[, keep, drop = FALSE])
}

cox_matrix_predict_redesign <- function(x_train, time, event, x_test) {
  d <- data.frame(time = time, event = event, x_train, check.names = FALSE)
  formula <- as.formula(paste("Surv(time,event) ~", paste(colnames(x_train), collapse = "+")))
  fit <- coxph(formula, data = d, x = TRUE, ties = "breslow")
  list(
    fit = fit,
    train_lp = as.numeric(predict(fit, type = "lp")),
    test_lp = as.numeric(predict(fit, newdata = data.frame(x_test, check.names = FALSE), type = "lp"))
  )
}

cindex_redesign <- function(time, event, score) {
  if (!is.finite(sd(score)) || sd(score) == 0) return(NA_real_)
  tryCatch(unname(concordance(Surv(time, event) ~ score, reverse = TRUE)$concordance),
           error = function(e) NA_real_)
}

standardize_lp_redesign <- function(train_lp, test_lp) {
  center <- mean(train_lp, na.rm = TRUE)
  scale <- sd(train_lp, na.rm = TRUE)
  if (!is.finite(scale) || scale <= 0) return(rep(0, length(test_lp)))
  (test_lp - center) / scale
}

tune_clinical_spec_redesign <- function(raw, inner_fold, specifications, seed) {
  tuning_rule <- tolower(Sys.getenv(
    "REDESIGN_CLINICAL_TUNING_RULE", "pooled"
  ))
  if (!tuning_rule %in% c("pooled", "fold_stratified")) {
    stop("Unknown REDESIGN_CLINICAL_TUNING_RULE: ", tuning_rule)
  }
  rows <- lapply(seq_along(specifications), function(s) {
    specification <- specifications[s]
    prediction <- rep(NA_real_, nrow(raw))
    fold_rows <- list()
    for (fold in sort(unique(inner_fold))) {
      analysis <- which(inner_fold != fold); assessment <- which(inner_fold == fold)
      design <- clinical_design_redesign(
        raw[analysis, ], raw[assessment, ], specification,
        seed + s * 100L + fold
      )
      fit <- tryCatch(cox_matrix_predict_redesign(
        design$train, raw$OS_time[analysis], raw$OS_event[analysis], design$test
      ), error = function(e) NULL)
      if (is.null(fit) || any(!is.finite(fit$test_lp))) {
        stop(
          "Clinical tuning failed for specification ", specification,
          ", inner fold ", fold, "."
        )
      }
      prediction[assessment] <- fit$test_lp
      concordance_fit <- survival::concordance(
        survival::Surv(raw$OS_time[assessment], raw$OS_event[assessment]) ~
          fit$test_lp,
        reverse = TRUE
      )
      comparable_pairs <- sum(unname(concordance_fit$count[
        c("concordant", "discordant", "tied.x")
      ]))
      fold_rows[[length(fold_rows) + 1L]] <- data.frame(
        inner_fold = fold,
        fold_cindex = unname(concordance_fit$concordance),
        comparable_pairs = comparable_pairs,
        stringsAsFactors = FALSE
      )
    }
    if (any(!is.finite(prediction))) {
      stop("Incomplete clinical inner-fold predictions for ", specification, ".")
    }
    fold_table <- do.call(rbind, fold_rows)
    fold_stratified_cindex <- with(
      fold_table,
      sum(fold_cindex * comparable_pairs) / sum(comparable_pairs)
    )
    pooled_cindex <- cindex_redesign(raw$OS_time, raw$OS_event, prediction)
    data.frame(
      clinical_specification = specification,
      inner_cindex = if (tuning_rule == "fold_stratified") {
        fold_stratified_cindex
      } else pooled_cindex,
      pooled_inner_cindex = pooled_cindex,
      fold_stratified_inner_cindex = fold_stratified_cindex,
      total_comparable_pairs = sum(fold_table$comparable_pairs),
      clinical_tuning_rule = tuning_rule,
      stringsAsFactors = FALSE
    )
  })
  result <- do.call(rbind, rows)
  result <- result[order(-result$inner_cindex, result$clinical_specification), ]
  list(selected = result$clinical_specification[1], table = result)
}

pool_gene_screen_redesign <- function(x, raw, clinical_designs = NULL) {
  pooling_method <- Sys.getenv("REDESIGN_GENE_POOLING_METHOD", "custom_normal")
  if (!pooling_method %in% c("custom_normal", "rubin_barnard_rubin")) {
    stop("Unknown REDESIGN_GENE_POOLING_METHOD: ", pooling_method)
  }
  rows <- lapply(seq_len(ncol(x)), function(j) {
    value <- as.numeric(scale(x[, j]))
    estimates <- variances <- df_complete <- numeric(0)
    designs <- if (is.null(clinical_designs)) list(NULL) else clinical_designs
    for (clinical in designs) {
      d <- data.frame(time = raw$OS_time, event = raw$OS_event, gene_z = value)
      if (!is.null(clinical)) d <- cbind(d, as.data.frame(clinical, check.names = FALSE))
      rhs <- setdiff(names(d), c("time", "event"))
      fit <- tryCatch(coxph(
        as.formula(paste("Surv(time,event) ~", paste(rhs, collapse = "+"))),
        data = d, ties = "breslow"
      ), error = function(e) NULL)
      if (!is.null(fit) && "gene_z" %in% names(coef(fit))) {
        estimates <- c(estimates, unname(coef(fit)["gene_z"]))
        variances <- c(variances, unname(vcov(fit)["gene_z", "gene_z"]))
        # Cox partial-likelihood nobs is the number of events.  Use events
        # minus fitted coefficients as the conservative complete-data residual
        # degrees of freedom for the Barnard-Rubin small-sample correction.
        df_complete <- c(df_complete, max(1, fit$nevent - length(coef(fit))))
      }
    }
    if (!length(estimates)) return(data.frame(
      gene_name = colnames(x)[j], coefficient = NA, SE = NA, HR = NA,
      pvalue = NA, degrees_of_freedom = NA, within_variance = NA,
      between_variance = NA, imputations_pooled = 0L,
      pooling_method = pooling_method
    ))
    qbar <- mean(estimates); ubar <- mean(variances)
    between <- if (length(estimates) > 1L) var(estimates) else 0
    total <- ubar + (1 + 1 / length(estimates)) * between
    se <- sqrt(total)
    use_small_sample <- pooling_method == "rubin_barnard_rubin" &&
      length(estimates) > 1L
    if (use_small_sample) {
      m <- length(estimates)
      dfcom <- min(df_complete)
      lambda <- if (is.finite(total) && total > 0) {
        (1 + 1 / m) * between / total
      } else 0
      lambda <- min(max(lambda, 0), 1)
      df_old <- if (lambda > 0) (m - 1) / lambda^2 else Inf
      df_obs <- ((dfcom + 1) / (dfcom + 3)) * dfcom * (1 - lambda)
      df <- if (is.finite(df_old)) 1 / (1 / df_old + 1 / df_obs) else df_obs
      p <- 2 * pt(-abs(qbar / se), df = df)
    } else {
      df <- Inf
      p <- 2 * pnorm(-abs(qbar / se))
    }
    data.frame(gene_name = colnames(x)[j], coefficient = qbar, SE = se,
               HR = exp(qbar), pvalue = p, degrees_of_freedom = df,
               within_variance = ubar, between_variance = between,
               imputations_pooled = length(estimates),
               pooling_method = if (use_small_sample) pooling_method else
                 "custom_normal")
  })
  result <- do.call(rbind, rows)
  result$FDR <- p.adjust(result$pvalue, method = "BH")
  result[order(result$pvalue, -abs(result$coefficient)), ]
}

tune_enet_redesign <- function(
  x_gene, ranked_genes, y, foldid, alpha_grid, candidate_limits,
  clinical = NULL, max_genes = 15L, allow_zero_genes = FALSE
) {
  rows <- list(); fits <- list(); k <- 1L
  ranked_genes <- intersect(ranked_genes, colnames(x_gene))
  for (limit in candidate_limits) {
    genes <- head(ranked_genes, min(limit, length(ranked_genes)))
    if (!length(genes)) next
    xg <- x_gene[, genes, drop = FALSE]
    x <- if (is.null(clinical)) xg else cbind(clinical, xg)
    penalty <- if (is.null(clinical)) rep(1, ncol(xg)) else
      c(rep(0, ncol(clinical)), rep(1, ncol(xg)))
    for (alpha in alpha_grid) {
      fit <- tryCatch(suppressWarnings(cv.glmnet(
        x, y, family = "cox", alpha = alpha, foldid = foldid,
        type.measure = "C", penalty.factor = penalty, standardize = TRUE,
        cox.ties = "breslow", keep = TRUE
      )), error = function(e) NULL)
      if (is.null(fit)) next
      for (lambda_rule in c("lambda.min", "lambda.1se")) {
        beta <- as.matrix(coef(fit, s = lambda_rule))[, 1]
        gene_beta <- beta[intersect(names(beta), genes)]
        n_gene <- sum(gene_beta != 0)
        lambda_value <- fit[[lambda_rule]]
        index <- which.min(abs(fit$lambda - lambda_value))
        oof_lp <- fit$fit.preval[, index]
        inner_survival <- tryCatch(survival_from_lp_redesign(
          y[, 1], y[, 2], oof_lp, oof_lp, c(365, 1095, 1825)
        ), error = function(e) NULL)
        inner_ibs <- if (is.null(inner_survival)) NA_real_ else {
          inner_brier <- vapply(seq_len(3L), function(ii) {
            ipcw_brier_redesign(y[, 1], y[, 2], inner_survival[, ii],
                                c(365, 1095, 1825)[ii])
          }, numeric(1))
          sum(diff(c(365, 1095, 1825)) *
                (head(inner_brier, -1) + tail(inner_brier, -1)) / 2) /
            (1825 - 365)
        }
        valid <- n_gene <= max_genes && (allow_zero_genes || n_gene >= 1L)
        key <- paste(limit, alpha, lambda_rule, sep = "|")
        fits[[key]] <- list(fit = fit, genes = genes, clinical_n = if (is.null(clinical)) 0L else ncol(clinical))
        rows[[k]] <- data.frame(
          candidate_limit = limit, alpha = alpha, lambda_rule = lambda_rule,
          lambda_value = lambda_value, inner_cindex = fit$cvm[index],
          inner_ibs = inner_ibs,
          selected_gene_count = n_gene,
          selected_genes = if (n_gene) paste(names(gene_beta)[gene_beta != 0], collapse = ";") else NA_character_,
          complexity_valid = valid, fit_key = key, stringsAsFactors = FALSE
        )
        k <- k + 1L
      }
    }
  }
  table <- do.call(rbind, rows)
  valid <- table[table$complexity_valid & is.finite(table$inner_cindex), ]
  if (!nrow(valid)) stop("No valid Elastic Net candidate satisfied complexity constraints.")
  best <- max(valid$inner_cindex)
  near <- valid[valid$inner_cindex >= best - 0.005, ]
  near <- near[order(near$inner_ibs, near$selected_gene_count, -near$lambda_value,
                     -near$alpha, near$candidate_limit), ]
  selected <- near[1, ]
  list(selected = selected, table = table, object = fits[[selected$fit_key]])
}

fit_enet_outer_redesign <- function(tuned, x_gene_train, x_gene_test, y,
                                    clinical_train = NULL, clinical_test = NULL) {
  genes <- tuned$object$genes
  x_train <- x_gene_train[, genes, drop = FALSE]
  x_test <- x_gene_test[, genes, drop = FALSE]
  if (!is.null(clinical_train)) {
    x_train <- cbind(clinical_train, x_train); x_test <- cbind(clinical_test, x_test)
    penalty <- c(rep(0, ncol(clinical_train)), rep(1, length(genes)))
  } else penalty <- rep(1, length(genes))
  fit <- glmnet(
    x_train, y, family = "cox", alpha = tuned$selected$alpha,
    lambda = tuned$selected$lambda_value, penalty.factor = penalty,
    standardize = TRUE, cox.ties = "breslow"
  )
  train_lp <- as.numeric(predict(fit, newx = x_train, type = "link"))
  test_lp <- as.numeric(predict(fit, newx = x_test, type = "link"))
  beta <- as.matrix(coef(fit))[, 1]
  list(fit = fit, train_lp = train_lp, test_lp = test_lp, beta = beta)
}

survival_from_lp_redesign <- function(time, event, train_lp, test_lp, horizons) {
  # Fold-specific calibration/shrinkage is estimated only in the analysis
  # patients. The assessment outcomes are never used for this step.
  fit <- coxph(Surv(time, event) ~ train_lp, ties = "breslow")
  slope <- unname(coef(fit)[1])
  bh <- basehaz(fit, centered = FALSE)
  h0 <- vapply(horizons, function(tt) {
    value <- bh$hazard[bh$time <= tt]
    if (length(value)) max(value) else 0
  }, numeric(1))
  exp(-outer(exp(slope * test_lp), h0))
}

step_survival_redesign <- function(sf, query_time) {
  vapply(query_time, function(tt) {
    idx <- which(sf$time < tt)
    if (!length(idx)) 1 else sf$surv[max(idx)]
  }, numeric(1))
}

ipcw_brier_redesign <- function(time, event, predicted_survival, horizon) {
  censor_fit <- survfit(Surv(time, 1 - event) ~ 1)
  g_t <- pmax(step_survival_redesign(censor_fit, rep(horizon, length(time))), 1e-6)
  g_i <- pmax(step_survival_redesign(censor_fit, time), 1e-6)
  weight <- ifelse(time <= horizon & event == 1, 1 / g_i,
                   ifelse(time > horizon, 1 / g_t, 0))
  outcome <- as.numeric(time > horizon)
  mean(weight * (outcome - predicted_survival)^2)
}

# Fit alpha/lambda candidates entirely inside one inner-training partition.
# The caller is responsible for fold-specific DEG discovery, screening,
# ranking, imputation and feature construction before invoking this helper.
evaluate_inner_enet_redesign <- function(
  x_gene_train, x_gene_valid, ranked_genes, raw_train, raw_valid,
  alpha_grid, clinical_specification = NULL, seed,
  max_genes = 15L, allow_zero_genes = FALSE,
  horizons = c(365, 1095, 1825)
) {
  genes <- head(intersect(ranked_genes, colnames(x_gene_train)), 20L)
  genes <- intersect(genes, colnames(x_gene_valid))
  if (length(genes) < 2L) stop("Fewer than two ranked genes in inner fold.")
  clinical <- if (is.null(clinical_specification)) NULL else
    clinical_design_redesign(
      raw_train, raw_valid, clinical_specification, seed
    )
  x_train <- x_gene_train[, genes, drop = FALSE]
  x_valid <- x_gene_valid[, genes, drop = FALSE]
  if (!is.null(clinical)) {
    x_train <- cbind(clinical$train, x_train)
    x_valid <- cbind(clinical$test, x_valid)
    penalty <- c(rep(0, ncol(clinical$train)), rep(1, length(genes)))
  } else {
    penalty <- rep(1, length(genes))
  }
  y <- Surv(raw_train$OS_time, raw_train$OS_event)
  subfold <- make_stratified_folds_redesign(
    raw_train$OS_event, 5L, seed + 7000L
  )
  rows <- list(); predictions <- list(); k <- 1L
  for (alpha in alpha_grid) {
    fit <- tryCatch(suppressWarnings(cv.glmnet(
      x_train, y, family = "cox", alpha = alpha, foldid = subfold,
      type.measure = "C", penalty.factor = penalty, standardize = TRUE,
      cox.ties = "breslow"
    )), error = function(e) NULL)
    if (is.null(fit)) next
    for (rule in c("lambda.min", "lambda.1se")) {
      target_lambda <- fit[[rule]]
      target_beta <- as.matrix(coef(fit, s = target_lambda))[, 1]
      target_gene_beta <- target_beta[intersect(names(target_beta), genes)]
      target_n_gene <- sum(target_gene_beta != 0)
      target_valid <- target_n_gene <= max_genes &&
        (allow_zero_genes || target_n_gene >= 1L)

      lambda_gene_counts <- vapply(fit$lambda, function(value) {
        b <- as.matrix(coef(fit, s = value))[, 1]
        sum(b[intersect(names(b), genes)] != 0)
      }, integer(1))
      eligible <- which(
        lambda_gene_counts <= max_genes &
          (allow_zero_genes | lambda_gene_counts >= 1L)
      )
      fallback_lambda <- if (length(eligible)) {
        chosen <- eligible[which.min(abs(
          log(fit$lambda[eligible]) - log(target_lambda)
        ))]
        fit$lambda[chosen]
      } else NA_real_

      variants <- list(
        list(lambda = target_lambda, suffix = "", fallback = FALSE)
      )
      if (is.finite(fallback_lambda)) variants[[2L]] <- list(
        lambda = fallback_lambda, suffix = "|cap_fallback", fallback = TRUE
      )
      for (variant in variants) {
        selected_lambda <- variant$lambda
        beta <- as.matrix(coef(fit, s = selected_lambda))[, 1]
        gene_beta <- beta[intersect(names(beta), genes)]
        n_gene <- sum(gene_beta != 0)
        valid <- n_gene <= max_genes && (allow_zero_genes || n_gene >= 1L)
        train_lp <- as.numeric(predict(
          fit, newx = x_train, s = selected_lambda, type = "link"
        ))
        valid_lp <- as.numeric(predict(
          fit, newx = x_valid, s = selected_lambda, type = "link"
        ))
        survival <- tryCatch(survival_from_lp_redesign(
          raw_train$OS_time, raw_train$OS_event,
          train_lp, valid_lp, horizons
        ), error = function(e) matrix(
          NA_real_, nrow = nrow(raw_valid), ncol = length(horizons)
        ))
        key <- paste0(paste(alpha, rule, sep = "|"), variant$suffix)
        predictions[[key]] <- list(
          lp = standardize_lp_redesign(train_lp, valid_lp),
          survival = survival
        )
        rows[[k]] <- data.frame(
          candidate_limit = 20L, alpha = alpha, lambda_rule = rule,
          lambda_value = selected_lambda, target_lambda_value = target_lambda,
          cap_adjusted = !isTRUE(all.equal(selected_lambda, target_lambda)),
          fallback_candidate = variant$fallback,
          selected_gene_count = n_gene,
          selected_genes = if (n_gene) paste(
            names(gene_beta)[gene_beta != 0], collapse = ";"
          ) else NA_character_,
          complexity_valid = valid, fit_key = key,
          stringsAsFactors = FALSE
        )
        k <- k + 1L
      }
    }
  }
  list(table = do.call(rbind, rows), predictions = predictions, genes = genes)
}

select_end_to_end_tuning_redesign <- function(
  fold_results, raw, fold_id, horizons = c(365, 1095, 1825)
) {
  keys <- Reduce(intersect, lapply(
    fold_results, function(z) unique(z$table$fit_key)
  ))
  rows <- lapply(keys, function(key) {
    lp <- rep(NA_real_, nrow(raw))
    survival <- matrix(NA_real_, nrow(raw), length(horizons))
    complexity <- logical(0); fallback <- logical(0); gene_count <- numeric(0)
    lambda <- numeric(0); selected_genes <- character(0)
    for (fold in sort(unique(fold_id))) {
      z <- fold_results[[as.character(fold)]]
      idx <- which(fold_id == fold)
      record <- z$table[z$table$fit_key == key, , drop = FALSE]
      prediction <- z$predictions[[key]]
      lp[idx] <- prediction$lp
      survival[idx, ] <- prediction$survival
      complexity <- c(complexity, record$complexity_valid)
      fallback <- c(fallback, record$fallback_candidate)
      gene_count <- c(gene_count, record$selected_gene_count)
      lambda <- c(lambda, record$lambda_value)
      selected_genes <- c(selected_genes, record$selected_genes)
    }
    brier <- vapply(seq_along(horizons), function(j) {
      ipcw_brier_redesign(
        raw$OS_time, raw$OS_event, survival[, j], horizons[j]
      )
    }, numeric(1))
    parts <- strsplit(key, "[|]")[[1]]
    data.frame(
      candidate_limit = 20L, alpha = as.numeric(parts[1]),
      lambda_rule = parts[2], lambda_value = median(lambda),
      inner_cindex = cindex_redesign(raw$OS_time, raw$OS_event, lp),
      inner_ibs = sum(diff(horizons) *
        (head(brier, -1) + tail(brier, -1)) / 2) /
        diff(range(horizons)),
      selected_gene_count = max(gene_count),
      selected_gene_count_median = median(gene_count),
      selected_genes = paste(unique(na.omit(selected_genes)), collapse = "|"),
      complexity_valid = all(complexity), fallback_candidate = all(fallback),
      fit_key = key,
      stringsAsFactors = FALSE
    )
  })
  table <- do.call(rbind, rows)
  valid <- table[table$complexity_valid & is.finite(table$inner_cindex) &
                   is.finite(table$inner_ibs), , drop = FALSE]
  if (!nrow(valid)) stop("No leakage-safe end-to-end tuning candidate.")
  primary_valid <- valid[!valid$fallback_candidate, , drop = FALSE]
  if (nrow(primary_valid)) valid <- primary_valid
  best <- max(valid$inner_cindex)
  near <- valid[valid$inner_cindex >= best - 0.005, , drop = FALSE]
  near <- near[order(
    near$inner_ibs, near$selected_gene_count_median,
    near$lambda_rule != "lambda.1se", -near$alpha
  ), , drop = FALSE]
  list(selected = near[1, , drop = FALSE], table = table)
}

# Refit a fold model after all hyperparameters have been selected by the
# leakage-safe end-to-end inner procedure. Standardization is learned by
# glmnet from the full outer-analysis matrix only.
refit_selected_enet_redesign <- function(
  selected, x_gene_train, x_gene_test, ranked_genes, raw_train, inner_fold,
  clinical_train = NULL, clinical_test = NULL, max_genes = 15L
) {
  genes <- head(intersect(ranked_genes, colnames(x_gene_train)), 20L)
  genes <- intersect(genes, colnames(x_gene_test))
  x_train <- x_gene_train[, genes, drop = FALSE]
  x_test <- x_gene_test[, genes, drop = FALSE]
  if (!is.null(clinical_train)) {
    x_train <- cbind(clinical_train, x_train)
    x_test <- cbind(clinical_test, x_test)
    penalty <- c(rep(0, ncol(clinical_train)), rep(1, length(genes)))
  } else penalty <- rep(1, length(genes))
  fit_cv <- suppressWarnings(cv.glmnet(
    x_train, Surv(raw_train$OS_time, raw_train$OS_event),
    family = "cox", alpha = selected$alpha, foldid = inner_fold,
    type.measure = "C", penalty.factor = penalty, standardize = TRUE,
    cox.ties = "breslow"
  ))
  rule <- selected$lambda_rule
  lambda <- fit_cv[[rule]]
  beta <- as.matrix(coef(fit_cv, s = lambda))[, 1]
  gene_count <- sum(beta[intersect(names(beta), genes)] != 0)
  if (gene_count > max_genes) {
    counts <- vapply(fit_cv$lambda, function(value) {
      b <- as.matrix(coef(fit_cv, s = value))[, 1]
      sum(b[intersect(names(b), genes)] != 0)
    }, integer(1))
    eligible <- which(counts <= max_genes)
    if (!length(eligible)) stop("No final fold lambda satisfies gene cap.")
    lambda <- fit_cv$lambda[eligible[which.min(abs(
      fit_cv$lambda[eligible] - lambda
    ))]]
  }
  fit <- glmnet(
    x_train, Surv(raw_train$OS_time, raw_train$OS_event),
    family = "cox", alpha = selected$alpha, lambda = lambda,
    penalty.factor = penalty, standardize = TRUE, cox.ties = "breslow"
  )
  list(
    fit = fit,
    train_lp = as.numeric(predict(fit, newx = x_train, type = "link")),
    test_lp = as.numeric(predict(fit, newx = x_test, type = "link")),
    beta = as.matrix(coef(fit))[, 1], genes = genes, lambda_value = lambda
  )
}
