suppressPackageStartupMessages({library(survival);library(dplyr)})
run<-getwd();out<-"final_audit";dir.create(out,showWarnings=FALSE)
r<-function(p)read.delim(p,check.names=FALSE)
w<-function(x,n)write.table(x,file.path(out,n),sep="\t",quote=FALSE,row.names=FALSE,na="NA")
source("scripts/lib_incremental_redesign.R")
primary<-r("tables/model/redesign/primary_estimand_aligned/patient_cluster_bootstrap_replicates.tsv")
stopifnot(nrow(primary)==1000L,all(vapply(primary,function(x)all(is.finite(x)),logical(1))))
f<-readRDS("results/model/redesign/frozen_incremental_joint_model.rds")
old<-readRDS("C:/tekyazar/handoff/M20_fold_stratified_clinical_selection_2026-09-11_v1_stage/results/model/redesign/frozen_incremental_joint_model.rds")
stopifnot(f$development_n==352L,f$development_events==127L,length(f$selected_genes)<=15L,
 f$clinical_imputation$imputations==20L,f$clinical_imputation$pack_pmm_rule=="smoking_constrained")
baselines<-bind_rows(lapply(c("Clinical_only","Combined"),function(m){
 b<-if(m=="Clinical_only")f$clinical_only_baseline_hazard else f$baseline_hazard
 slope<-if(m=="Clinical_only")f$clinical_only_calibration_slope else f$calibration_slope
 stopifnot(nrow(b)==318L,all(is.finite(b$hazard)),all(diff(b$hazard)>=-1e-14),all(diff(b$time)>0),is.finite(slope))
 data.frame(model=m,time_days=b$time,cumulative_baseline_hazard=b$hazard,calibration_slope=slope)
}))
w(baselines,"complete_frozen_baseline_hazards.tsv")
w(data.frame(term=names(f$clinical_only_coefficients),coefficient=as.numeric(f$clinical_only_coefficients)),"clinical_only_coefficients.tsv")
w(data.frame(item=c("clinical_specification","alpha","lambda_rule","lambda","selected_gene_count","selected_genes","clinical_coefficients_identical_to_S25","joint_coefficients_identical_to_S25"),
 value=c(f$clinical_specification,f$alpha,f$lambda_rule,f$lambda,length(f$selected_genes),paste(f$selected_genes,collapse=";"),
 isTRUE(all.equal(f$clinical_only_coefficients,old$clinical_only_coefficients,tolerance=0)),isTRUE(all.equal(f$coefficients,old$coefficients,tolerance=0)))),"frozen_model_comparison.tsv")
grid<-sort(unique(c(seq(30,1825,length.out=100L),365,1095,1825)));stopifnot(length(grid)==102L)
w(data.frame(time_index=seq_along(grid),time_days=grid),"external_probability_time_grid.tsv")
S<-function(lp,m){
 b<-if(m=="clinical")f$clinical_only_baseline_hazard else f$baseline_hazard
 slope<-if(m=="clinical")f$clinical_only_calibration_slope else f$calibration_slope
 h<-c(0,b$hazard)[findInterval(grid,b$time)+1L]
 exp(-outer(exp(slope*lp),h))
}
external<-r("tables/external_validation/external_incremental_validation.tsv")
boot<-r("tables/external_validation/external_incremental_bootstrap_replicates.tsv")
stopifnot(all(vapply(split(boot$replicate,boot$analysis),function(v)length(unique(v))==1000L,logical(1))),
 all(table(boot$analysis[boot$metric=="C_index"])==1000L))
curves<-list();metrics<-list();objects<-list();horizons<-list()
for(cohort in c("GSE72094","GSE31210")){
 d<-r(paste0("results/external_validation/redesign/",cohort,"_incremental_predictions.tsv"))
 stopifnot(nrow(d)==if(cohort=="GSE72094")398L else 226L,!anyDuplicated(d$sample_id),
 all(is.finite(d$clinical_lp)),all(is.finite(d$combined_lp)),sd(d$combined_lp)>0)
 sc<-S(d$clinical_lp,"clinical");sj<-S(d$combined_lp,"combined")
 stopifnot(all(is.finite(sc)),all(is.finite(sj)),all(sc>=0 & sc<=1),all(sj>=0 & sj<=1))
 objects[[cohort]]<-list(sample_id=d$sample_id,clinical=sc,combined=sj)
 h<-d
 for(t in c(365,1095,1825)){h[[paste0("clinical_survival_",t,"d")]]<-sc[,match(t,grid)];h[[paste0("combined_survival_",t,"d")]]<-sj[,match(t,grid)]}
 horizons[[cohort]]<-h
 sets<-if(cohort=="GSE72094")list(GSE72094_primary=seq_len(nrow(d))) else list(GSE31210_primary_exploratory=seq_len(nrow(d)),GSE31210_excluding_22_flagged=which(!d$prognosis_exclusion_flag))
 for(an in names(sets)){
  idx<-sets[[an]];z<-d[idx,];row<-external[external$analysis==an,];stopifnot(nrow(row)==1L)
  for(m in c("clinical","combined")){
   a<-if(m=="clinical")sc[idx,,drop=FALSE] else sj[idx,,drop=FALSE]
   bs<-vapply(seq_along(grid),function(j)ipcw_brier_redesign(z$OS_time,z$OS_event,a[,j],grid[j]),numeric(1))
   ibs<-sum(diff(grid)*(head(bs,-1)+tail(bs,-1))/2)/diff(range(grid))
   ci<-unname(concordance(Surv(OS_time,OS_event)~z[[paste0(m,"_lp")]],data=z,reverse=TRUE)$concordance)
   stopifnot(abs(ibs-row[[paste0(m,"_IBS")]])<1e-10,abs(ci-row[[paste0(m,"_cindex")]])<1e-10)
   curves[[length(curves)+1L]]<-data.frame(cohort=cohort,analysis=an,model=m,time_days=grid,IPCW_Brier=bs)
   metrics[[length(metrics)+1L]]<-data.frame(cohort=cohort,analysis=an,model=m,n=nrow(z),events=sum(z$OS_event),C_index=ci,IBS=ibs)
  }
 }
}
w(bind_rows(curves),"external_Brier_curves_102_points.tsv");w(bind_rows(metrics),"external_C_IBS_independent_reproduction.tsv")
w(bind_rows(horizons),"external_patient_predictions_1y_3y_5y.tsv")
saveRDS(list(time_grid=grid,cohorts=objects),file.path(out,"external_dense_frozen_survival.rds"),compress="xz")
stopifnot(sum(!horizons$GSE31210$prognosis_exclusion_flag)==204L)
w(data.frame(check=c("primary_bootstrap_replicates","external_bootstrap_replicates_per_analysis","external_analysis_sets","baseline_rows","external_probability_grid","final_gene_count","independent_external_C_IBS_matches"),result=c(1000,1000,3,636,102,length(f$selected_genes),TRUE)),"VALIDATION.tsv")
capture.output(sessionInfo(),file=file.path(out,"sessionInfo.txt"))
writeLines(c("# Completed inner crossfit downstream audit",paste("Date",Sys.Date()),
 "Primary C-index CI uses the repeat-wise fold-stratified patient-cluster bootstrap in tables/model/redesign/primary_estimand_aligned.",
 "Script 19 bootstrap outputs are secondary patient-averaged OOF-ensemble estimates and must not be labeled as the primary estimand CI.",
 "Bootstrap is conditional on already fitted OOF predictions; the entire modeling pipeline was not refitted inside each replicate.",
 paste("Final model:",f$clinical_specification,"alpha",f$alpha,f$lambda_rule,"lambda",format(f$lambda,digits=15),"genes",length(f$selected_genes)),
 paste("Selected genes:",paste(f$selected_genes,collapse=", ")),
 "External outputs were regenerated with the new isolated frozen model. C-index and 102-point IBS were independently reproduced from frozen LPs, baselines and calibration slopes. External IBS uses days 30-1825; no claim of a 30-730-day S37 analysis is made.",
 "The original script-18 AUDIT_REPORT in output_audit describes that earlier stage; this final audit supersedes its statement that bootstrap/refit/external work had not yet occurred."),file.path(out,"FINAL_AUDIT_REPORT.md"))
cat("FINAL DOWNSTREAM AUDIT PASS\n");print(r("tables/model/redesign/primary_estimand_aligned/patient_cluster_bootstrap_summary.tsv"));print(bind_rows(metrics))
