suppressPackageStartupMessages(library(survival))
run <- getwd()
out <- "tables/model/redesign/primary_estimand_aligned"
dir.create(out,recursive=TRUE,showWarnings=FALSE)
paths <- c(corrected_S25="C:/tekyazar/handoff/M20_fold_stratified_clinical_selection_2026-09-11_v1_stage/results/model/nested_cv/paired_oof_predictions.tsv",
 inner_crossfit="results/model/nested_cv/paired_oof_predictions.tsv")
data <- lapply(paths,function(p)read.delim(p,check.names=FALSE))
patients<-sort(unique(data$inner_crossfit$patient_id));stopifnot(length(patients)==352L)
for(d in data)stopifnot(nrow(d)==3520L,setequal(unique(d$patient_id),patients))
sets<-lapply(data,function(d)split(d,d$repetition))
calc<-function(parts,freq){
 m<-vapply(parts,function(d){
  d$w<-as.numeric(freq[match(d$patient_id,patients)]);d<-d[d$w>0,]
  c(clinical=unname(concordance(Surv(OS_time,OS_event)~clinical_lp+strata(outer_fold),data=d,weights=w,reverse=TRUE)$concordance),
    combined=unname(concordance(Surv(OS_time,OS_event)~combined_lp+strata(outer_fold),data=d,weights=w,reverse=TRUE)$concordance))
 },numeric(2))
 x<-rowMeans(m);c(clinical=x[1],combined=x[2],delta=x[2]-x[1])
}
B<-1000L;set.seed(20261016L)
reps<-vector("list",B)
for(b in seq_len(B)){
 freq<-tabulate(sample.int(352L,352L,replace=TRUE),nbins=352L)
 x<-calc(sets$corrected_S25,freq);y<-calc(sets$inner_crossfit,freq)
 reps[[b]]<-data.frame(replicate=b,S25_clinical=x[1],S25_combined=x[2],S25_delta=x[3],
  crossfit_clinical=y[1],crossfit_combined=y[2],crossfit_delta=y[3],change_in_delta=y[3]-x[3])
 if(b%%100L==0L)cat("Primary aligned bootstrap",b,"/",B,"\n")
}
reps<-do.call(rbind,reps);stopifnot(all(vapply(reps,function(v)all(is.finite(v)),logical(1))))
point0<-calc(sets$corrected_S25,rep(1,352));point1<-calc(sets$inner_crossfit,rep(1,352))
summ<-do.call(rbind,lapply(c("S25_delta","crossfit_delta","change_in_delta"),function(n){
 p<-switch(n,S25_delta=point0[3],crossfit_delta=point1[3],change_in_delta=point1[3]-point0[3])
 data.frame(contrast=n,point_estimate=unname(p),bootstrap_mean=mean(reps[[n]]),lower95=unname(quantile(reps[[n]],.025)),upper95=unname(quantile(reps[[n]],.975)),replicates=B,
 estimand="mean_over_repeats_of_fold_stratified_comparable_pair_weighted_C_difference",scope="conditional_on_fitted_OOF_not_full_pipeline_refitting")
}))
write.table(reps,file.path(out,"patient_cluster_bootstrap_replicates.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
write.table(summ,file.path(out,"patient_cluster_bootstrap_summary.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
capture.output(sessionInfo(),file=file.path(out,"sessionInfo.txt"));print(summ)
