# ============================================================
# Finalize the incremental-value redesign after repeated nested CV
# ============================================================

suppressPackageStartupMessages({
  library(SummarizedExperiment)
  library(tidyverse)
  library(survival)
  library(glmnet)
  library(timeROC)
})
source("scripts/lib_analysis_rules.R")
source("scripts/lib_incremental_redesign.R")

dir.create("results/model/redesign", recursive = TRUE, showWarnings = FALSE)
dir.create("tables/model/redesign", recursive = TRUE, showWarnings = FALSE)

horizons <- c(365, 1095, 1825)
bootstrap_replicates <- as.integer(Sys.getenv("REDESIGN_BOOTSTRAP_REPLICATES", "1000"))
imputations <- as.integer(Sys.getenv("REDESIGN_IMPUTATIONS", "5"))
match_ranking_to_comparator <- identical(
  tolower(Sys.getenv("REDESIGN_MATCH_RANKING_TO_COMPARATOR", "false")), "true"
)
gene_pooling_method <- Sys.getenv(
  "REDESIGN_GENE_POOLING_METHOD", "custom_normal"
)
stopifnot(gene_pooling_method %in% c("custom_normal", "rubin_barnard_rubin"))
feature_transform <- Sys.getenv("REDESIGN_FEATURE_TRANSFORM", "s_score")
stopifnot(feature_transform %in% c("s_score", "yugene"))
stopifnot(bootstrap_replicates >= 100L)
stopifnot(imputations >= 2L)

development_source <- read.delim("results/model/risk_scores_training.tsv", check.names = FALSE)
secondary_source <- read.delim("results/model/risk_scores_testing.tsv", check.names = FALSE)
development <- prepare_raw_clinical_redesign(development_source)
secondary <- prepare_raw_clinical_redesign(secondary_source)
stopifnot(nrow(development) == 352L, nrow(secondary) == 152L)

# Recreate the frozen 15-reference-gene percentile transformation.
luad_exp <- readRDS("data_raw/TCGA_LUAD_STAR_counts_SE.rds")
count_matrix <- if ("unstranded" %in% assayNames(luad_exp))
  assay(luad_exp, "unstranded") else assay(luad_exp, 1)
sample_info <- as.data.frame(colData(luad_exp))
gene_info <- as.data.frame(rowData(luad_exp))
sample_info$sample_barcode <- rownames(sample_info)
sample_info$patient_id <- substr(sample_info$sample_barcode, 1, 12)
tumor_info <- select_one_sample_per_patient_type(sample_info) %>%
  filter(sample_type == "Primary Tumor") %>% arrange(patient_id, sample_barcode)
all_patients <- c(development$patient_id, secondary$patient_id)
tumor_info <- tumor_info %>% filter(patient_id %in% all_patients)
stopifnot(all(all_patients %in% tumor_info$patient_id))

tumor_counts <- round(count_matrix[, tumor_info$sample_barcode, drop = FALSE])
storage.mode(tumor_counts) <- "integer"
log_cpm <- log2(sweep(tumor_counts, 2, colSums(tumor_counts), "/") * 1e6 + 1)
gene_symbols <- toupper(trimws(as.character(gene_info$gene_name)))
names(gene_symbols) <- rownames(gene_info)
reference_genes <- c(
  "ACTB", "B2M", "GAPDH", "GUSB", "HMBS", "HPRT1", "PGK1",
  "PPIA", "RPL13A", "RPLP0", "SDHA", "TBP", "TFRC", "UBC", "YWHAZ"
)
reference_ids <- vapply(reference_genes, function(symbol) {
  hit <- names(gene_symbols)[gene_symbols == symbol]
  if (length(hit)) hit[1] else NA_character_
}, character(1))
stopifnot(!anyNA(reference_ids))
reference_matrix <- log_cpm[reference_ids, , drop = FALSE]
rownames(reference_matrix) <- reference_genes

yugene_matrix <- NULL
if (feature_transform == "yugene") {
  gene_level_log_cpm <- aggregate_symbol_matrix_redesign(
    log_cpm[, tumor_info$sample_barcode, drop = FALSE], gene_symbols
  )
  yugene_matrix <- yugene_transform_redesign(gene_level_log_cpm)
  rm(gene_level_log_cpm)
  gc()
}
write.table(data.frame(
  feature_transform = feature_transform,
  implementation = if (feature_transform == "yugene")
    "exact_archived_CRAN_YuGene_1.1.6_algorithm" else
    "16_level_reference_panel_percentile_S_score",
  duplicate_symbol_rule = if (feature_transform == "yugene")
    "arithmetic_mean_before_transform" else "first_annotated_Ensembl_row",
  feature_universe_genes = if (feature_transform == "yugene")
    nrow(yugene_matrix) else length(reference_genes),
  outcome_used = FALSE, stringsAsFactors = FALSE
), "tables/model/redesign/feature_transformation_audit.tsv",
sep = "\t", quote = FALSE, row.names = FALSE)

build_features <- function(gene_names, patient_ids) {
  gene_names <- unique(toupper(as.character(gene_names)))
  if (feature_transform == "yugene") {
    gene_names <- intersect(gene_names, rownames(yugene_matrix))
    barcodes <- tumor_info$sample_barcode[match(patient_ids, tumor_info$patient_id)]
    return(t(yugene_matrix[gene_names, barcodes, drop = FALSE]))
  }
  gene_ids <- vapply(gene_names, function(symbol) {
    hit <- names(gene_symbols)[gene_symbols == symbol]
    if (length(hit)) hit[1] else NA_character_
  }, character(1))
  keep <- !is.na(gene_ids)
  gene_names <- gene_names[keep]; gene_ids <- gene_ids[keep]
  barcodes <- tumor_info$sample_barcode[match(patient_ids, tumor_info$patient_id)]
  refs <- reference_matrix[, barcodes, drop = FALSE]
  out <- t(vapply(seq_along(gene_ids), function(i) {
    (1 + colSums(sweep(refs, 2, log_cpm[gene_ids[i], barcodes], FUN = "<="))) /
      (nrow(refs) + 1)
  }, numeric(length(barcodes))))
  rownames(out) <- gene_names; colnames(out) <- patient_ids
  t(out)
}

top500 <- read.delim("results/DEG/DEG_top500_for_survival.tsv", check.names = FALSE)
top500_genes <- unique(toupper(top500$gene_name))
x_development <- build_features(top500_genes, development$patient_id)
x_secondary <- build_features(top500_genes, secondary$patient_id)
common <- intersect(colnames(x_development), colnames(x_secondary))
x_development <- x_development[, common, drop = FALSE]
x_secondary <- x_secondary[, common, drop = FALSE]

# Determine the modal nested clinical comparator before the full-development
# adjusted screen so the opt-in sensitivity can match its ranking model.
clinical_tuning_all <- read.delim(
  "tables/model/redesign/clinical_specification_inner_selection.tsv"
) %>% filter(selected)
stopifnot(nrow(clinical_tuning_all) == 50L)
modal_clinical_for_ranking <- clinical_tuning_all %>%
  count(clinical_specification, name = "selected_outer_folds") %>%
  mutate(complexity = case_when(
    grepl("none_linear", clinical_specification) ~ 1L,
    grepl("pack_linear|ever_linear", clinical_specification) ~ 2L,
    TRUE ~ 3L
  )) %>% arrange(desc(selected_outer_folds), complexity, clinical_specification) %>%
  slice(1)
ranking_specification <- if (match_ranking_to_comparator) {
  as.character(modal_clinical_for_ranking$clinical_specification)
} else "pack_linear"

# Separate full-development screens. The canonical analysis uses pack_linear;
# the opt-in sensitivity uses the modal comparator selected across outer folds.
univariate_screen <- pool_gene_screen_redesign(x_development, development)
adjusted_designs <- lapply(seq_len(imputations), function(m) {
  clinical_design_redesign(
    development, development, ranking_specification, 91000L + m
  )$train
})
adjusted_screen <- pool_gene_screen_redesign(
  x_development, development, adjusted_designs
)
survival_genes <- univariate_screen$gene_name[
  is.finite(univariate_screen$pvalue) & univariate_screen$pvalue < 0.05
]
adjusted_screen$passed_univariate_p05 <-
  adjusted_screen$gene_name %in% survival_genes
write.table(univariate_screen, "tables/model/univariate_gene_screen.tsv",
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(adjusted_screen, "tables/model/clinical_adjusted_gene_screen.tsv",
            sep = "\t", quote = FALSE, row.names = FALSE)

# Lock the final pipeline by the modal nested-CV choices. Ties are resolved in
# favor of fewer candidate genes, stronger regularization, and simpler coding.
tuning <- read.delim("tables/model/elastic_net_alpha_lambda_selection.tsv") %>%
  filter(selected, model == "Combined")
stopifnot(nrow(tuning) == 50L)
modal_pipeline <- tuning %>%
  count(candidate_limit, alpha, lambda_rule, name = "selected_outer_folds") %>%
  arrange(desc(selected_outer_folds), candidate_limit, desc(alpha),
          desc(lambda_rule == "lambda.1se")) %>% slice(1)
clinical_tuning <- clinical_tuning_all
stopifnot(nrow(clinical_tuning) == 50L)
modal_clinical <- clinical_tuning %>%
  count(clinical_specification, name = "selected_outer_folds") %>%
  mutate(complexity = case_when(
    grepl("none_linear", clinical_specification) ~ 1L,
    grepl("pack_linear|ever_linear", clinical_specification) ~ 2L,
    TRUE ~ 3L
  )) %>% arrange(desc(selected_outer_folds), complexity, clinical_specification) %>%
  slice(1)

pipeline_lock <- data.frame(
  item = c("candidate_limit", "alpha", "lambda_rule", "clinical_specification",
           "ranking_clinical_specification", "ranking_strategy",
           "gene_pooling_method", "feature_transform",
           "max_gene_count", "reference_panel", "development_n", "secondary_n"),
  value = c(modal_pipeline$candidate_limit, modal_pipeline$alpha,
            modal_pipeline$lambda_rule, modal_clinical$clinical_specification,
            ranking_specification,
            if (match_ranking_to_comparator) "comparator_matched" else "fixed_pack_linear",
            gene_pooling_method,
            feature_transform,
            15, paste(reference_genes, collapse = ";"), 352, 152),
  selection_basis = c(rep("modal choice across 50 outer folds", 4),
                      "matched to modal clinical comparator", "sensitivity lock",
                      "sensitivity lock", "sensitivity lock", "design lock", "design lock", "cohort role lock",
                      "cohort role lock"), stringsAsFactors = FALSE
)
write.table(pipeline_lock, "tables/model/redesign/final_pipeline_lock.tsv",
            sep = "\t", quote = FALSE, row.names = FALSE)

candidate_genes <- head(
  adjusted_screen$gene_name[adjusted_screen$passed_univariate_p05],
                        as.integer(modal_pipeline$candidate_limit))
xg <- x_development[, candidate_genes, drop = FALSE]
clinical <- clinical_design_redesign(
  development, secondary, modal_clinical$clinical_specification, 92001L
)
y <- Surv(development$OS_time, development$OS_event)
foldid <- make_stratified_folds_redesign(development$OS_event, 5L, 92002L)
x_joint <- cbind(clinical$train, xg)
penalty <- c(rep(0, ncol(clinical$train)), rep(1, ncol(xg)))
cvfit <- cv.glmnet(
  x_joint, y, family = "cox", alpha = as.numeric(modal_pipeline$alpha),
  foldid = foldid, type.measure = "C", penalty.factor = penalty,
  standardize = TRUE, cox.ties = "breslow", keep = TRUE
)
lambda_rule <- as.character(modal_pipeline$lambda_rule)
lambda_value <- cvfit[[lambda_rule]]
beta_candidate <- as.matrix(coef(cvfit, s = lambda_rule))[, 1]
gene_count <- sum(beta_candidate[candidate_genes] != 0)
if (gene_count > 15L) {
  valid <- vapply(seq_along(cvfit$lambda), function(i) {
    b <- as.matrix(coef(cvfit$glmnet.fit, s = cvfit$lambda[i]))[, 1]
    sum(b[candidate_genes] != 0) <= 15L
  }, logical(1))
  near <- which(valid & cvfit$cvm >= max(cvfit$cvm, na.rm = TRUE) - 0.005)
  if (!length(near)) stop("No final lambda satisfies the locked 15-gene cap.")
  chosen <- near[order(-cvfit$cvm[near], -cvfit$lambda[near])][1]
  lambda_value <- cvfit$lambda[chosen]
  lambda_rule <- "complexity_constrained_near_optimum"
}
final_fit <- glmnet(
  x_joint, y, family = "cox", alpha = as.numeric(modal_pipeline$alpha),
  lambda = lambda_value, penalty.factor = penalty, standardize = TRUE,
  cox.ties = "breslow"
)
final_beta <- as.matrix(coef(final_fit))[, 1]
selected_genes <- candidate_genes[final_beta[candidate_genes] != 0]
stopifnot(length(selected_genes) <= 15L)

training_lp <- as.numeric(predict(final_fit, newx = x_joint, type = "link"))
x_secondary_joint <- cbind(clinical$test, x_secondary[, candidate_genes, drop = FALSE])
secondary_lp <- as.numeric(predict(final_fit, newx = x_secondary_joint, type = "link"))
calibration_fit <- coxph(y ~ training_lp, ties = "breslow")
calibration_slope <- unname(coef(calibration_fit)[1])
baseline <- basehaz(calibration_fit, centered = FALSE)
exploratory_cutoff <- median(training_lp)

coefficient_table <- data.frame(
  term = names(final_beta),
  term_type = ifelse(names(final_beta) %in% candidate_genes, "gene", "clinical"),
  coefficient = as.numeric(final_beta),
  selected = as.numeric(final_beta) != 0,
  stringsAsFactors = FALSE
) %>% arrange(term_type, desc(abs(coefficient)))
write.table(coefficient_table, "tables/model/redesign/final_joint_model_coefficients.tsv",
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(data.frame(patient_id = development$patient_id, fold = foldid),
            "tables/model/redesign/final_refit_cv_fold_assignment.tsv",
            sep = "\t", quote = FALSE, row.names = FALSE)

frozen <- list(
  version = if (feature_transform == "yugene") {
    "incremental_redesign_v3_M20_YuGene_full_pipeline_sensitivity"
  } else if (gene_pooling_method == "rubin_barnard_rubin") {
    "incremental_redesign_v3_M20_Rubin_Barnard_Rubin_pooling_sensitivity"
  } else if (match_ranking_to_comparator) {
    "incremental_redesign_v4_M20_comparator_matched_ranking_sensitivity"
  } else "incremental_redesign_v2_end_to_end", created = as.character(Sys.Date()),
  development_n = 352L, development_events = sum(development$OS_event),
  secondary_role = "previously_observed_secondary_internal_validation_cohort",
  reference_genes = reference_genes, candidate_genes = candidate_genes,
  selected_genes = selected_genes,
  ranking_clinical_specification = ranking_specification,
  ranking_strategy = if (match_ranking_to_comparator) {
    "comparator_matched"
  } else "fixed_pack_linear",
  gene_pooling_method = gene_pooling_method,
  feature_transform = feature_transform,
  clinical_specification = modal_clinical$clinical_specification,
  clinical_columns = colnames(clinical$train),
  clinical_imputation = list(
    imputations = imputations,
    pack_pmm_rule = Sys.getenv(
      "REDESIGN_PACK_PMM_RULE", "legacy_unconstrained"
    ),
    never_smoker_missing_pack_years = if (identical(
      Sys.getenv("REDESIGN_PACK_PMM_RULE", "legacy_unconstrained"),
      "smoking_constrained"
    )) "structural_zero" else "legacy_unconstrained_pmm",
    unknown_smoking_status = if (identical(
      Sys.getenv("REDESIGN_PACK_PMM_RULE", "legacy_unconstrained"),
      "smoking_constrained"
    )) "explicit_indicator_all_observed_training_donors" else "mode_imputed",
    age_median = median(development$age, na.rm = TRUE),
    stage_mode = mode_numeric_redesign(development$stage, 1),
    male_mode = mode_numeric_redesign(development$male, 0),
    ever_smoking_mode = mode_numeric_redesign(development$ever_smoking, 1)
  ),
  alpha = as.numeric(modal_pipeline$alpha), lambda_rule = lambda_rule,
  lambda = lambda_value, penalty_factor = penalty, glmnet_fit = final_fit,
  coefficients = final_beta, calibration_slope = calibration_slope,
  baseline_hazard = baseline, exploratory_cutoff = exploratory_cutoff
)
saveRDS(frozen, "results/model/redesign/frozen_incremental_joint_model.rds",
        compress = "xz")

survival_from_frozen <- function(lp, time_grid) {
  h0 <- vapply(time_grid, function(tt) {
    z <- baseline$hazard[baseline$time <= tt]
    if (length(z)) max(z) else 0
  }, numeric(1))
  exp(-outer(exp(calibration_slope * lp), h0))
}

clinical_fit <- cox_matrix_predict_redesign(
  clinical$train, development$OS_time, development$OS_event, clinical$test
)
clinical_training_lp <- clinical_fit$train_lp
clinical_secondary_lp <- clinical_fit$test_lp
# Calibrate both clinical-only and combined absolute risks by the identical
# development-only model Surv(time,event) ~ linear_predictor.
clinical_calibration_fit <- coxph(
  Surv(development$OS_time, development$OS_event) ~ clinical_training_lp,
  ties = "breslow"
)
frozen$clinical_only_coefficients <- coef(clinical_fit$fit)
frozen$clinical_only_fit <- clinical_fit$fit
frozen$clinical_only_calibration_slope <-
  unname(coef(clinical_calibration_fit)[1])
clinical_baseline <- basehaz(clinical_calibration_fit, centered = FALSE)
frozen$clinical_only_baseline_hazard <- clinical_baseline
saveRDS(frozen, "results/model/redesign/frozen_incremental_joint_model.rds",
        compress = "xz")
clinical_surv <- survival_from_lp_redesign(
  development$OS_time, development$OS_event,
  clinical_training_lp, clinical_secondary_lp, sort(unique(c(seq(30, 1825,
    length.out = 100L), horizons)))
)
time_grid <- sort(unique(c(seq(30, 1825, length.out = 100L), horizons)))
combined_surv <- survival_from_frozen(secondary_lp, time_grid)

evaluate_secondary <- function(model, lp, surv) {
  auc <- suppressWarnings(timeROC(
    T = secondary$OS_time, delta = secondary$OS_event, marker = lp,
    cause = 1, weighting = "marginal", times = horizons, iid = FALSE
  )$AUC)
  brier <- vapply(seq_along(time_grid), function(j) {
    ipcw_brier_redesign(secondary$OS_time, secondary$OS_event, surv[, j], time_grid[j])
  }, numeric(1))
  hi <- match(horizons, time_grid)
  data.frame(
    cohort_role = "previously_observed_secondary_internal_validation_cohort",
    interpretation = "descriptive_only_not_independent_or_confirmatory",
    model = model, n = nrow(secondary), events = sum(secondary$OS_event),
    cindex = cindex_redesign(secondary$OS_time, secondary$OS_event, lp),
    AUC_1y = auc[1], AUC_3y = auc[2], AUC_5y = auc[3],
    Brier_1y = brier[hi[1]], Brier_3y = brier[hi[2]], Brier_5y = brier[hi[3]],
    IBS = sum(diff(time_grid) * (head(brier, -1) + tail(brier, -1)) / 2) /
      (max(time_grid) - min(time_grid)),
    calibration_slope = tryCatch(unname(coef(coxph(
      Surv(secondary$OS_time, secondary$OS_event) ~ lp))[1]),
      error = function(e) NA_real_), stringsAsFactors = FALSE
  )
}
secondary_table <- bind_rows(
  evaluate_secondary("Clinical_only", clinical_secondary_lp, clinical_surv),
  evaluate_secondary("Combined_frozen", secondary_lp, combined_surv)
)
write.table(secondary_table, "tables/model/secondary_internal_validation.tsv",
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(data.frame(
  patient_id = secondary$patient_id, OS_time = secondary$OS_time,
  OS_event = secondary$OS_event, clinical_lp = clinical_secondary_lp,
  combined_lp = secondary_lp,
  combined_exploratory_group = ifelse(secondary_lp > exploratory_cutoff,
                                      "High", "Low")
), "results/model/redesign/secondary_internal_predictions.tsv",
sep = "\t", quote = FALSE, row.names = FALSE)

# Pre-specified clinical and nonlinear sensitivity summaries from all inner
# comparisons, not from the secondary cohort.
clinical_all <- read.delim(
  "tables/model/redesign/clinical_specification_inner_selection.tsv"
)
imputation_sensitivity <- clinical_all %>%
  mutate(smoking_coding = case_when(
    grepl("^pack", clinical_specification) ~ "multiply_imputed_pack_years",
    grepl("^ever", clinical_specification) ~ "raw_ever_never",
    TRUE ~ "no_smoking"
  )) %>% group_by(smoking_coding) %>% summarise(
    comparisons = n(), selected_outer_folds = sum(selected),
    mean_inner_cindex = mean(inner_cindex),
    median_inner_cindex = median(inner_cindex), .groups = "drop"
  )
write.table(imputation_sensitivity, "tables/model/clinical_imputation_sensitivity.tsv",
            sep = "\t", quote = FALSE, row.names = FALSE)
nonlinear_sensitivity <- clinical_all %>%
  mutate(age_form = ifelse(grepl("nonlinear", clinical_specification),
                           "ns_age_df3", "linear_age"),
         pack_year_form = case_when(
           clinical_specification == "pack_nonlinear" ~ "ns_log1p_pack_years_df3",
           clinical_specification == "pack_linear" ~ "linear_log1p_pack_years",
           TRUE ~ "not_in_model")) %>%
  group_by(age_form, pack_year_form) %>% summarise(
    comparisons = n(), selected_outer_folds = sum(selected),
    mean_inner_cindex = mean(inner_cindex),
    median_inner_cindex = median(inner_cindex), .groups = "drop"
  )
write.table(nonlinear_sensitivity, "tables/model/nonlinear_clinical_sensitivity.tsv",
            sep = "\t", quote = FALSE, row.names = FALSE)

# Patient-cluster paired bootstrap. Predictions are first averaged across the
# ten OOF repeats; a sampled patient always contributes both comparator scores.
oof <- read.delim("results/model/nested_cv/paired_oof_predictions.tsv")
oof_average <- oof %>% group_by(patient_id, OS_time, OS_event) %>% summarise(
  clinical_lp = mean(clinical_lp), combined_lp = mean(combined_lp),
  across(matches("^(clinical|combined)_surv_"), mean), .groups = "drop"
)
dense_object <- readRDS("results/model/redesign/dense_oof_survival_predictions.rds")
stopifnot(dense_object$repeats == 10L, length(dense_object$time_grid) == 102L)
patient_order <- oof_average$patient_id
dense_mean <- lapply(c("clinical", "combined"), function(model) {
  accumulator <- matrix(0, nrow = length(patient_order),
                        ncol = length(dense_object$time_grid))
  for (object in dense_object$rows) {
    idx <- match(object$patient_id, patient_order)
    accumulator[idx, ] <- accumulator[idx, ] + object[[model]] / 10
  }
  accumulator
})
names(dense_mean) <- c("clinical", "combined")

ipcw_curve <- function(time, event, predicted, grid) {
  censor_fit <- survfit(Surv(time, 1 - event) ~ 1)
  g_i <- pmax(step_survival_redesign(censor_fit, time), 1e-6)
  vapply(seq_along(grid), function(j) {
    tt <- grid[j]
    g_t <- pmax(step_survival_redesign(censor_fit, rep(tt, length(time))), 1e-6)
    weight <- ifelse(time <= tt & event == 1, 1 / g_i,
                     ifelse(time > tt, 1 / g_t, 0))
    mean(weight * (as.numeric(time > tt) - predicted[, j])^2)
  }, numeric(1))
}

set.seed(93001L)
cindex_boot <- vector("list", bootstrap_replicates)
auc_boot <- vector("list", bootstrap_replicates)
brier_boot <- vector("list", bootstrap_replicates)
ibs_boot <- vector("list", bootstrap_replicates)
hi <- match(horizons, dense_object$time_grid)
for (b in seq_len(bootstrap_replicates)) {
  idx <- sample(seq_len(nrow(oof_average)), replace = TRUE)
  z <- oof_average[idx, ]
  c_clin <- cindex_redesign(z$OS_time, z$OS_event, z$clinical_lp)
  c_comb <- cindex_redesign(z$OS_time, z$OS_event, z$combined_lp)
  cindex_boot[[b]] <- data.frame(replicate = b, clinical = c_clin,
                                  combined = c_comb, delta = c_comb - c_clin)
  auc_clin <- tryCatch(suppressWarnings(timeROC(
    T = z$OS_time, delta = z$OS_event, marker = z$clinical_lp,
    cause = 1, weighting = "marginal", times = horizons, iid = FALSE)$AUC),
    error = function(e) rep(NA_real_, 3))
  auc_comb <- tryCatch(suppressWarnings(timeROC(
    T = z$OS_time, delta = z$OS_event, marker = z$combined_lp,
    cause = 1, weighting = "marginal", times = horizons, iid = FALSE)$AUC),
    error = function(e) rep(NA_real_, 3))
  auc_boot[[b]] <- data.frame(replicate = b, horizon_days = horizons,
                               clinical = auc_clin, combined = auc_comb,
                               delta = auc_comb - auc_clin)
  bc <- ipcw_curve(z$OS_time, z$OS_event, dense_mean$clinical[idx, , drop = FALSE],
                   dense_object$time_grid)
  bj <- ipcw_curve(z$OS_time, z$OS_event, dense_mean$combined[idx, , drop = FALSE],
                   dense_object$time_grid)
  brier_boot[[b]] <- data.frame(replicate = b, horizon_days = horizons,
                                 clinical = bc[hi], combined = bj[hi],
                                 delta = bj[hi] - bc[hi])
  ibs_c <- sum(diff(dense_object$time_grid) *
                 (head(bc, -1) + tail(bc, -1)) / 2) /
    diff(range(dense_object$time_grid))
  ibs_j <- sum(diff(dense_object$time_grid) *
                 (head(bj, -1) + tail(bj, -1)) / 2) /
    diff(range(dense_object$time_grid))
  ibs_boot[[b]] <- data.frame(replicate = b, clinical = ibs_c,
                               combined = ibs_j, delta = ibs_j - ibs_c)
}
cindex_boot <- bind_rows(cindex_boot); auc_boot <- bind_rows(auc_boot)
brier_boot <- bind_rows(brier_boot); ibs_boot <- bind_rows(ibs_boot)
write.table(cindex_boot, "tables/model/paired_delta_cindex_bootstrap.tsv",
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(auc_boot, "tables/model/paired_delta_auc_bootstrap.tsv",
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(brier_boot, "tables/model/paired_delta_brier_bootstrap.tsv",
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(ibs_boot, "tables/model/paired_delta_ibs_bootstrap.tsv",
            sep = "\t", quote = FALSE, row.names = FALSE)

bootstrap_summary <- bind_rows(
  data.frame(metric = "C_index", horizon_days = NA_integer_,
             estimate = mean(cindex_boot$delta),
             lower95 = quantile(cindex_boot$delta, .025, na.rm = TRUE),
             upper95 = quantile(cindex_boot$delta, .975, na.rm = TRUE)),
  auc_boot %>% group_by(horizon_days) %>% summarise(
    metric = "AUC", estimate = mean(delta, na.rm = TRUE),
    lower95 = quantile(delta, .025, na.rm = TRUE),
    upper95 = quantile(delta, .975, na.rm = TRUE), .groups = "drop"),
  brier_boot %>% group_by(horizon_days) %>% summarise(
    metric = "Brier", estimate = mean(delta, na.rm = TRUE),
    lower95 = quantile(delta, .025, na.rm = TRUE),
    upper95 = quantile(delta, .975, na.rm = TRUE), .groups = "drop"),
  data.frame(metric = "IBS", horizon_days = NA_integer_,
             estimate = mean(ibs_boot$delta),
             lower95 = quantile(ibs_boot$delta, .025, na.rm = TRUE),
             upper95 = quantile(ibs_boot$delta, .975, na.rm = TRUE))
) %>% select(metric, horizon_days, estimate, lower95, upper95)
write.table(bootstrap_summary, "tables/model/redesign/paired_bootstrap_summary.tsv",
            sep = "\t", quote = FALSE, row.names = FALSE)

cat("Incremental redesign finalization completed.\n")
cat("Selected genes:", paste(selected_genes, collapse = ", "), "\n")
cat("Final clinical specification:", modal_clinical$clinical_specification, "\n")
cat("Final alpha/lambda:", modal_pipeline$alpha, lambda_rule, lambda_value, "\n")
print(secondary_table)
print(bootstrap_summary)
