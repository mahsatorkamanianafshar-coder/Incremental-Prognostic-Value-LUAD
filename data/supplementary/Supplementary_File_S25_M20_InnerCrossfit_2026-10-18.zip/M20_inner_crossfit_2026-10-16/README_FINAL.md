﻿# Complete isolated M20 corrective inner crossfit handoff

Completed 2026-10-16. This v2 package supersedes the script-18-only v1 handoff for completion status. It includes all 50 corrective outer analyses and 3520 OOF predictions, output validation, fold-stratified primary estimates, a 1000-replicate estimand-aligned paired patient-cluster bootstrap, final full-development refit, frozen clinical comparator, and regenerated external validation with 1000 paired bootstrap replicates per analysis set.

Primary results are in output_audit/primary_fold_stratified_summary.tsv and tables/model/redesign/primary_estimand_aligned/. Script 19's tables/model/paired_delta_* files target the secondary patient-averaged OOF-ensemble estimand, not the primary repeated fold-stratified C-index estimand. Conditional OOF bootstrap does not refit the entire pipeline within each replicate.

The final model and coefficients are in results/model/redesign/frozen_incremental_joint_model.rds and tables/model/redesign/final_joint_model_coefficients.tsv. final_audit/frozen_model_comparison.tsv identifies numerical identity or changes against S25. Deployment must use this run's frozen object, coefficients and calibration together. The object retains the historical version label used by script 19; run-specific provenance is supplied in the exact scripts, logs and manifests.

External results include GSE72094 (398), GSE31210 full eligible (226) and protocol-aligned (204). final_audit provides the 102-point time grid, independently reproduced Brier/IBS curves, all frozen survival arrays and patient-level 1/3/5-year predictions. Standard external IBS uses 30-1825 days. The separate 30-730-day S37 diagnostic was not calculated in this workflow.

The earlier output_audit/AUDIT_REPORT.md and RUN_DESIGN.md document the script-18 stage and its original scope. Their statements that downstream stages had not yet run are historical and superseded by this report and final_audit/FINAL_AUDIT_REPORT.md.

Large raw inputs and expression/discovery cache payloads are not duplicated. Original locations/hashes and discovery-cache manifest are supplied. Canonical project outputs have not been replaced. Complete R warning lists were not retained by the original scripts; available stderr logs and audit limitations are preserved. Scientific interpretation must retain uncertainty rather than claim definitive model superiority.

MANIFEST.tsv covers every payload except itself. Every ZIP payload hash is verified after extraction, and the adjacent ZIP SHA-256 file verifies the delivered archive.
Primary delta-C: 0.0202798934572882; percentile 95% CI -0.00583586564728091 to 0.0448536229692808.

