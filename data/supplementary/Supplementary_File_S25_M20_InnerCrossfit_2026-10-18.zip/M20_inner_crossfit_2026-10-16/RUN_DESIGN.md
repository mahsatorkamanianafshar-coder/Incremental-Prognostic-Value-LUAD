# Corrective inner clinical selection sensitivity

Prepared 2026-10-15. Execute the supplied script 18 in the original R 4.5.1 environment, using the project's existing R library. Original supplied R script is copied byte-for-byte. All inputs are private file copies; no output paths or directory junctions point back to canonical project output directories.

Settings: M=20, ten repeats, five outer folds, five inner folds, smoking-constrained PMM, fold-stratified clinical selection, fixed pack_linear adjusted ranking, S-score, custom_normal pooling. Inner-training clinical selection uses its own five-fold sub-CV. Newly fingerprinted discovery caches are built in this run; the original 300 caches are not reused.

Scope is the supplied script 18. Final refit, external validation, bootstrap and manuscript replacement are not part of this launch. The supplied script's terminal repeat C-index summaries use pooled LP concordance; primary fold-stratified summaries require separate post-run audit of the OOF predictions. Dense 102-point survival predictions and outer checkpoints are retained by script 18.

Resume from outer checkpoints by running run_isolated.ps1 only if the previous process has stopped and final paired_oof_predictions.tsv has not yet been produced. Do not start duplicate processes. INPUT_SHA256.tsv preserves input/code identity; stdout, stderr, sessionInfo and inner_crossfit_status.tsv record execution. Completed status means script 18 exited successfully, with scientific output validation still pending.
