$ErrorActionPreference='Stop'
$root='C:\tekyazar'
$run=Join-Path $root 'sensitivity_runs\M20_inner_crossfit_corrective_2026-10-15_v1'
Set-Location -LiteralPath $run
$env:R_LIBS_USER=Join-Path $root 'renv\library\windows\R-4.5\x86_64-w64-mingw32'
$env:REDESIGN_IMPUTATIONS='20';$env:REDESIGN_REPEATS='10'
$env:REDESIGN_PACK_PMM_RULE='smoking_constrained'
$env:REDESIGN_MATCH_RANKING_TO_COMPARATOR='false'
$env:REDESIGN_GENE_POOLING_METHOD='custom_normal';$env:REDESIGN_FEATURE_TRANSFORM='s_score'
$env:REDESIGN_CLINICAL_TUNING_RULE='fold_stratified'
$env:REDESIGN_BOOTSTRAP_REPLICATES='1000';$env:EXTERNAL_INCREMENTAL_BOOTSTRAP='1000'
$env:REDESIGN_EXTERNAL_OUTPUT_TAG=''
$env:REDESIGN_FROZEN_PATH='results/model/redesign/frozen_incremental_joint_model.rds'
$rscript='C:\Program Files\R\R-4.5.1\bin\Rscript.exe'
function Status($phase,$state,$code){[pscustomobject]@{timestamp=(Get-Date).ToString('o');phase=$phase;status=$state;exit_code=$code;launcher_pid=$PID;imputations=20;bootstrap_replicates=1000;scope='isolated_inner_crossfit_downstream'}|Export-Csv -LiteralPath 'downstream_status.tsv' -Delimiter "`t" -NoTypeInformation -Encoding UTF8}
try{
 foreach($step in @(@('primary_aligned_bootstrap','bootstrap_inner_crossfit_primary.R'),@('final_refit_secondary_bootstrap','19_finalize_incremental_redesign.R'),@('freeze_clinical','20_freeze_clinical_comparator.R'),@('external_validation_bootstrap','21_external_incremental_validation.R'))){
  Status $step[0] 'running' -1
  $ErrorActionPreference='Continue'
  & $rscript --vanilla ('scripts/'+$step[1]) 1> ($step[0]+'.stdout.log') 2> ($step[0]+'.stderr.log')
  $code=$LASTEXITCODE;$ErrorActionPreference='Stop'
  if($code -ne 0){Status $step[0] 'failed' $code;exit $code}
 }
 Status 'downstream_completed_pending_final_audit' 'completed' 0
}catch{$_|Out-String|Set-Content 'downstream_error.txt';Status 'runtime' 'failed' 1;exit 1}
