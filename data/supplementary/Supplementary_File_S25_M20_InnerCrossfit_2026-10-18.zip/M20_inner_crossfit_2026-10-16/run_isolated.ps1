param([string]$RunRoot='C:\tekyazar\sensitivity_runs\M20_inner_crossfit_corrective_2026-10-15_v1')
$ErrorActionPreference='Stop'
$project='C:\tekyazar'
$expected='C:\tekyazar\sensitivity_runs\M20_inner_crossfit_corrective_2026-10-15_v1'
if([IO.Path]::GetFullPath($RunRoot) -ne $expected){throw 'Unexpected isolated run directory'}
Set-Location -LiteralPath $RunRoot
$env:R_LIBS_USER='C:\tekyazar\renv\library\windows\R-4.5\x86_64-w64-mingw32'
$env:REDESIGN_CROSSFIT_ISOLATED_RUN='YES'
$env:REDESIGN_REPEATS='10'
$env:REDESIGN_IMPUTATIONS='20'
$env:REDESIGN_PACK_PMM_RULE='smoking_constrained'
$env:REDESIGN_CLINICAL_TUNING_RULE='fold_stratified'
$env:REDESIGN_REQUIRE_EXISTING_DISCOVERY_CACHE='false'
$env:REDESIGN_MATCH_RANKING_TO_COMPARATOR='false'
$env:REDESIGN_GENE_POOLING_METHOD='custom_normal'
$env:REDESIGN_FEATURE_TRANSFORM='s_score'
$env:REDESIGN_DESEQ_WORKERS='1'
$rscript='C:\Program Files\R\R-4.5.1\bin\Rscript.exe'
function Status([string]$phase,[string]$state,[int]$code){
 [pscustomobject]@{timestamp=(Get-Date).ToString('o');status=$state;phase=$phase;exit_code=$code;launcher_pid=$PID;repeats=10;outer_folds=5;inner_folds=5;imputations=20;clinical_selection='inner_training_subcv_v1';pmm_rule='smoking_constrained';discovery='new_fingerprinted_caches';scope='script_18_only_no_final_refit_or_bootstrap'} |
 Export-Csv -LiteralPath 'inner_crossfit_status.tsv' -Delimiter "`t" -NoTypeInformation -Encoding UTF8
}
try{
 Status 'preflight' 'running' -1
 $ErrorActionPreference='Continue'
 & $rscript --vanilla 'scripts/preflight_inner_crossfit_corrective.R' 1> 'preflight.stdout.log' 2> 'preflight.stderr.log'
 $preflightCode=$LASTEXITCODE
 $ErrorActionPreference='Stop'
 if($preflightCode -ne 0){Status 'preflight' 'failed' $preflightCode;exit $preflightCode}
 Status 'nested_cv' 'running' -1
 $ErrorActionPreference='Continue'
 & $rscript --vanilla 'scripts/18_inner_crossfit_corrective_sensitivity.R' 1> '18_inner_crossfit.stdout.log' 2> '18_inner_crossfit.stderr.log'
 $code=$LASTEXITCODE
 $ErrorActionPreference='Stop'
 if($code -ne 0){Status 'nested_cv' 'failed' $code;exit $code}
 foreach($row in (Import-Csv -LiteralPath 'INPUT_SHA256.tsv' -Delimiter "`t")){
  if((Get-FileHash -LiteralPath $row.isolated_path -Algorithm SHA256).Hash.ToLower() -ne $row.sha256){throw ('Isolated input changed: '+$row.isolated_path)}
  if((Get-FileHash -LiteralPath $row.original_path -Algorithm SHA256).Hash.ToLower() -ne $row.sha256){throw ('Original input changed: '+$row.original_path)}
 }
 Status 'script_18_completed_pending_output_audit' 'completed' 0
}catch{
 $_ | Out-String | Set-Content -LiteralPath 'launcher_error.txt' -Encoding UTF8
 Status 'runtime_or_integrity' 'failed' 1
 exit 1
}
