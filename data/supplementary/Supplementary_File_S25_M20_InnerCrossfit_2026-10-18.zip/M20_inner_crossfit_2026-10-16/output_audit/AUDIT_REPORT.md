# Corrective inner crossfit output audit
Audit date: 2026-10-16
All 50 outer analyses completed. OOF structure, 1250 inner specification rows/250 selections, 102-point survival arrays and IPCW IBS reproduction passed.
Primary performance is fold-stratified comparable-pair-weighted concordance averaged over ten repeats. The supplied script's pooled C-index output is retained as a secondary diagnostic, not the primary estimate.
         variant clinical_C combined_C repeat_SD_delta_C     delta_C
1  corrected_S25 0.65516511 0.67714776      0.0091531986 0.021982655
2 inner_crossfit 0.65516511 0.67544500      0.0106714827 0.020279893
The comparison uses corrected Sept 11 S25 with matching patient/repeat/fold/outcome identities. No new bootstrap CI, final refit, external evaluation or deployment model was generated.
Console reports 50 or more warnings without retaining a complete final warnings() list. The logged DESeq2 dispersion fallback is preserved; successful structural checks do not establish that every unrecorded warning was benign.
